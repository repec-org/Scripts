package ReDIF::Parser::Input;

##  Copyright (c) 1997-2001 Ivan Kurmanov. All rights reserved.
##
##  This code is free software; you can redistribute it and/or modify it
##  under the same terms as Perl itself.

$VERSION = '0.1';  ### $Id: Input.pm,v 1.17 2001/12/11 19:35:30 ivan Exp $

use ReDIF::Unicode qw( &has_utf8_bom &utf8_from_latin1 );

use strict;

use vars qw( 
	     $BUFFER
	     $CURRENT_BUFFER_POSITION

	     $CURRENT_FILE_POSITION
	     $LINE_NUMBER

	     $SOURCE_ENCODING 
	     $PARSER_MODULE 
	     $FILENAME 

	     $Options 

	     $DEBUG
	     );

# $DEBUG = 1;  ###  DEBUGGING

$BUFFER = ' ' x 1000;
my $CHUNK_SIZE = 400;

my $LINE_ENDING ;

my $THE_LINE = ' 'x 1000;
my $THE_LINE_ORIGINAL = ' 'x 1000;
my $THE_LINE_FILE_POSITION;
my $THE_LINE_BUFFER_POSITION;
my $THE_LINE_LENGTH;

my $eol_length;

my $EOF_STATUS;
my $ATTRIBUTE;

my $PARSING_STRING =0;
$PARSER_MODULE = "ReDIF::ParserCore";

sub init {
    my $opt = shift;

    if( defined $opt ) {
	$Options = $opt;
    } else {
	$Options = {};
    }
}

sub start_file {
    
    my $filename = shift;
    my $pos = shift;

    if( (not -e $filename)
	or (not -r _ ) 
	or (not -f _ ) 
	) {
	return undef;
    }

    $PARSING_STRING = 0;
    $FILENAME = $filename;

    ####  A Check for non-standart line-termination

    close FILE;
    open FILE, "<$filename";
    read FILE, $BUFFER, $CHUNK_SIZE;
    
    ###  line ending autodetection
    if ( $BUFFER =~ /[^\r\n]\n\r[^\r\n]/ ) { $LINE_ENDING = "\r"; }
    elsif ( $BUFFER =~ /[^\r\n]\r\n[^\r\n]/ ) { $LINE_ENDING = "\n"; }
    else { $LINE_ENDING = "\n" ; }

# ( $BUFFER =~ /[^\r\n]\n\r[^\r\n]/ ) { $LINE_ENDING = "\r"; }
#    if    ( $BUFFER =~ /[^\r\n]\n[^\r]/ )     { $LINE_ENDING = "\n"; }
#    elsif ( $BUFFER =~ /[^\r\n]\r\n/ )        { $LINE_ENDING = "\r\n"; }
#    elsif ( $BUFFER =~ /[^\r\n]\n\r[^\r\n]/ ) { $LINE_ENDING = "\n\r"; }
#    elsif ( $BUFFER =~ /[^\r\n]\r/ )          { $LINE_ENDING = "\r"; }

    $eol_length = length ( $LINE_ENDING );

    $CURRENT_BUFFER_POSITION = 0;
    $CURRENT_FILE_POSITION   = 0;
    
    ###  UNICODE
    
    if( has_utf8_bom( $BUFFER ) ) {
	$SOURCE_ENCODING = "utf-8";
	$CURRENT_BUFFER_POSITION = 3;
    } else {
	$SOURCE_ENCODING = "latin1";   
    }
    ####  

    $LINE_NUMBER = 0;

    if ( defined ($pos) and $pos ) {
	seek (FILE, $pos, 0);
	$FILENAME .= " (starting at $pos)";
	$CURRENT_FILE_POSITION = $pos;
	$BUFFER = '' ;
	undef $LINE_NUMBER;
    }
    
    undef $THE_LINE;
    $EOF_STATUS = 0;
    
    return 1;
    
}


sub start_string {
    
    my $string = shift;

    close FILE;

    $PARSING_STRING = 1;
    $FILENAME = "buffer string";
    $BUFFER = $string;

    ####  A Check for non-standart line-termination
    if ( $BUFFER =~ /[^\r\n]\n\r[^\r\n]/ ) { $LINE_ENDING = "\r"; }
    elsif ( $BUFFER =~ /[^\r\n]\r\n[^\r\n]/ ) { $LINE_ENDING = "\n"; }
    else { $LINE_ENDING = "\n" ; }

    $eol_length = length ( $LINE_ENDING );

    $CURRENT_BUFFER_POSITION = 0;
    $CURRENT_FILE_POSITION   = 0;
    
    ###  UNICODE
    
    if( has_utf8_bom( $BUFFER ) ) {
	$SOURCE_ENCODING = "utf-8";
	$CURRENT_BUFFER_POSITION = 3;
    } else {
	$SOURCE_ENCODING = "latin1";   
    }
    ####  

    $LINE_NUMBER = 0;

    undef $THE_LINE;
    $EOF_STATUS = 0;
    
    return 1;
}



sub extract_next_line {

    my $eof = shift;
    if( not defined $BUFFER or not length $BUFFER ) {
	return undef;
    }

    $THE_LINE_LENGTH = index( $BUFFER, $LINE_ENDING, $CURRENT_BUFFER_POSITION );
    
    if( $THE_LINE_LENGTH == -1 ) {
	if( not $eof ) {
	    $THE_LINE = '';
	    return undef;
	}
	$THE_LINE_LENGTH = length $BUFFER;
    }
    $THE_LINE_LENGTH -= $CURRENT_BUFFER_POSITION;

    $THE_LINE_BUFFER_POSITION = $CURRENT_BUFFER_POSITION;
    $THE_LINE = substr( $BUFFER, $CURRENT_BUFFER_POSITION, 
			   $THE_LINE_LENGTH+$eol_length );

    $CURRENT_BUFFER_POSITION += $THE_LINE_LENGTH + $eol_length; 
    if( defined $LINE_NUMBER ) { $LINE_NUMBER++; }

    return 1;
}


sub get_more_data_to_the_buffer {

    substr( $BUFFER, 0, $CURRENT_BUFFER_POSITION ) = '';

    $CURRENT_FILE_POSITION += $CURRENT_BUFFER_POSITION;
    $CURRENT_BUFFER_POSITION = 0;
    return read FILE, $BUFFER, $CHUNK_SIZE, length( $BUFFER ) ;
}

sub get_more_data_to_the_buffer2 {

    substr( $BUFFER, 0, $CURRENT_BUFFER_POSITION ) = '';

    $CURRENT_FILE_POSITION += $CURRENT_BUFFER_POSITION;
    $CURRENT_BUFFER_POSITION = 0;
    if( $PARSING_STRING ) { $EOF_STATUS = 1; return 0; }
    my $bytes = read( FILE, $BUFFER, $CHUNK_SIZE, length( $BUFFER ) );
    $EOF_STATUS = not $bytes;
    return $bytes;
}




sub extract_next_line_self_sufficient {

    undef $THE_LINE;
    undef $THE_LINE_LENGTH;
    undef $THE_LINE_BUFFER_POSITION;
    undef $THE_LINE_FILE_POSITION;

    my $t;
    my $buf_length = length( $BUFFER ) ;
    if( $EOF_STATUS
	and ($CURRENT_BUFFER_POSITION == $buf_length) ) {
#	if( defined $Options->{output_source} ) {
#	    $Options->{output_source}-> add_data( "> <EOF>" );
#	}
	return undef;
    }

    if( not defined $BUFFER or not $buf_length 
	or ($CURRENT_BUFFER_POSITION == $buf_length) ) {
	get_more_data_to_the_buffer2();
	if( $EOF_STATUS ) {
#	    if( defined $Options->{output_source} ) {
#		$Options->{output_source}-> add_data( "> <EOF>" );
#	    }
	    return undef;
	}
    }

    $THE_LINE_LENGTH = index( $BUFFER, $LINE_ENDING, $CURRENT_BUFFER_POSITION );
    
    if( $THE_LINE_LENGTH == -1 ) {
	if( not $EOF_STATUS ) {
	    get_more_data_to_the_buffer2();
	    if( not $EOF_STATUS ) {
		return extract_next_line_self_sufficient();
	    }
	} 
	$THE_LINE_LENGTH = $buf_length - $CURRENT_BUFFER_POSITION ;
	$eol_length = 0;

    } else {
	$THE_LINE_LENGTH -= $CURRENT_BUFFER_POSITION;
    }

    $THE_LINE_BUFFER_POSITION = $CURRENT_BUFFER_POSITION;
    $THE_LINE_FILE_POSITION = $CURRENT_BUFFER_POSITION + $CURRENT_FILE_POSITION;
    $THE_LINE_ORIGINAL = 
	$THE_LINE = substr( $BUFFER, $CURRENT_BUFFER_POSITION, 
			    $THE_LINE_LENGTH );
#			   $THE_LINE_LENGTH+$eol_length );
    
    $CURRENT_BUFFER_POSITION += $THE_LINE_LENGTH + $eol_length; 

    if( defined $LINE_NUMBER ) { $LINE_NUMBER++; }


    ###   UNICODE
    
    if( ( $SOURCE_ENCODING eq 'latin1' )  and $THE_LINE ) { 
	$THE_LINE = utf8_from_latin1 ( $THE_LINE );
    }
    
    return 1;
}



sub output_the_line {
    
    if( defined $Options->{output_source} ) {
	$Options->{output_source}-> add_data( "> $THE_LINE_ORIGINAL" );
    } 

    if( defined $Options->{output_source_utf8} ) {
	$Options->{output_source_utf8}-> add_data( "> $THE_LINE" );
    }    
}

sub extract_next_attribute {
    my $r;

    undef $ATTRIBUTE;
    my $send = 0;
    my $close = 0;
    my $close_later = 0;

    while( 1 ) {

	if( not defined $THE_LINE ) {
	    $r = extract_next_line_self_sufficient ( ) ;
	}
	
	if( defined $THE_LINE ) {
	    if ( $THE_LINE =~ /^\s*$/ ) {
		output_the_line();
		undef $THE_LINE;
		if( $EOF_STATUS ) { last; }
		next;
	    }

#	    print "LINE: $THE_LINE";

	    my ( $a, $v ) = $THE_LINE =~ /^([a-z\-]+):\s*(.+)?/i;

	    if( $a ) {
		if( lc( $a ) eq 'template-type' ) {
		    if( defined $ATTRIBUTE ) {
			$close_later = 1;
		    } else {
#			$close = 1;
		    }
		}
		if( defined $ATTRIBUTE ) {
		    ### send the attribute
		    last;
		} else {
		    
		    $ATTRIBUTE = {};
		    $ATTRIBUTE->{file_position} = $THE_LINE_FILE_POSITION;
		    if( defined $LINE_NUMBER ) {
			$ATTRIBUTE->{line_number} = $LINE_NUMBER;
		    }
		    $ATTRIBUTE->{attribute} = $a;
		    $ATTRIBUTE->{value} = $v ? $v : '';

		    output_the_line();
		    undef $THE_LINE;
		}

	    } else {
		if( defined $ATTRIBUTE ) {
		    $ATTRIBUTE->{value} .= "\n";
		    $ATTRIBUTE->{value} .= $THE_LINE;
		    output_the_line();
		    undef $THE_LINE;

		} else {
		    $ATTRIBUTE = {};
		    $ATTRIBUTE->{file_position} = $THE_LINE_FILE_POSITION;

		    if( defined $LINE_NUMBER ) {
			$ATTRIBUTE->{line_number} = $LINE_NUMBER;
		    }
		    $ATTRIBUTE->{value} = $THE_LINE;
		    output_the_line();
		    undef $THE_LINE;
		    last;
		}
		    
	    }
	} else {
	    if( $EOF_STATUS ) {
#		warn "EOF reached";
#		return undef;
	    }
	}

	if( $EOF_STATUS ) {
	    $close_later = 1;
	    last;
	}

    }

    if( defined $ATTRIBUTE ) {
	$ATTRIBUTE->{value} =~ s/\s+$//;
    }

    if( defined $Options->{attribute_output} ) {
	my $attr_out = $Options->{attribute_output};
	if( defined $ATTRIBUTE ) {	    
	    warn "sending '" . lc( $ATTRIBUTE->{attribute} ) . "' ..."
		if $DEBUG;

	    ### FLUSH
	    $attr_out->the_attribute( lc $ATTRIBUTE->{attribute}, 
				      $ATTRIBUTE->{value}, 
				      $ATTRIBUTE->{file_position},
				      $ATTRIBUTE->{line_number}
				      );

	    if( defined $Options->{output_source} ) {
		$Options->{output_source}-> flush_data_buffer ();
	    } 
	    if( defined $Options->{output_source_utf8} ) {
		$Options->{output_source_utf8}-> flush_data_buffer ();
	    }    

	}
    }

    if( not defined $ATTRIBUTE ) {
#	if( defined $Options->{attribute_output} ) {
#	    warn "closing template (2)"
#		if $DEBUG;
#	    my $attr_out = $Options->{attribute_output};
#	    $attr_out-> close_current_template ();
#	}
	return undef;
    }

    if( $close_later ) {
	if( defined $Options->{attribute_output} ) {
	    warn "closing template (2)"
		if $DEBUG;
	    my $attr_out = $Options->{attribute_output};
	    $attr_out-> close_current_template ();
	}
    }

    return $ATTRIBUTE;
}




sub process_file {
    my $filename = shift;
    my $position = shift; 
    my $eof_reached = 0;

    my @LINES;

    start_file ( $filename, $position ) or return undef;
    
    while( 1 ) {
	while( 1 ) {
	    my $got_line = extract_next_line_self_sufficient ( );
	    my $pos = $THE_LINE_FILE_POSITION;
	    if( not $got_line ) {
		last;
	    }
	    my $line = { text   => $THE_LINE       , 
			 length => $THE_LINE_LENGTH,
			 pos => $pos
			 };

	    push @LINES, $line;
	}
	if( $EOF_STATUS ) { last; }
#	$eof_reached = not get_more_data_to_the_buffer ( );
    }
    
    close FILE;
    return( $EOF_STATUS,  [ @LINES ] );
}


sub get_line_ending { return $LINE_ENDING ; }
sub get_the_line    { return $THE_LINE ; }
sub get_the_line_length { return $THE_LINE_LENGTH ; }



sub self_test_extract_next_line {
    my $file_name = shift;
    my $enc = shift;
    my $line_lengths = shift;

    my @results ;
    
    start_file( $file_name );
    push @results, 
        $LINE_ENDING, 
        defined( $CURRENT_BUFFER_POSITION ), 
        defined( $CURRENT_FILE_POSITION ), 
        defined( $SOURCE_ENCODING ), 
        

    

}

1;
