package SD::Graph;


=pod
=head1 NAME

SD::Graph - a special Graph class for the SD (Structured Document)
classes.  It is a numerical and array-based directed graph structure,
designed to represent and contain content model elements.

=cut

###   RCS keywords:
###
###   $Author: ivan $
###   $Date: 1999/12/20 13:29:17 $
###   $Id: Graph.pm,v 1.1 1999/12/20 13:29:17 ivan Exp ivan $
###   $Revision: 1.1 $
###   $Source: /home/ivan/devel/parser/SD/SD/Graph.pm,v $
###
###   $Log: Graph.pm,v $
###   Revision 1.1  1999/12/20 13:29:17  ivan
###   Initial revision
###
###    

use Devel::Assert ':DEBUG';

use strict;

=head1 SYNOPSYS

    use SD::Graph;

    $gr = SD::Graph -> new ();

    #####  GRAPH BUILDING METHODS

    @DATA = ( 'item', 'data' ) ;
    $item_no = $gr -> add_item ( @DATA ) ;

    $gr -> add_link ( 2, 3 );
    $gr -> add_links ( [0, 1, 2], [4, 5] );

    #####  GRAPH NAVIGATION METHODS

    @items = $gr -> alternatives ();
    @item_data = $gr -> move_to ( $items[0] );
    @item_data = $gr -> reset ( );

    #####  FINAL TEST

    if ( $gr-> final_reachable ) {
	....
    }
    $f = $gr -> final;

    #####  ITEM ACCESSOR METHOD

    @item_data = $gr -> get_item ( $number );
    @item_data = $gr -> set_item ( $number, @NEWDATA );

=head1 DESCRIPTION

This is the simplest-possible graph-class for purposes of the SD
(Structured Document) validation modules.  In particular, such graphs
objects will be used as a part of Finite State Automata
specifications.

The graphs are directed.  The vertices are identified by an integer
number.  A graph is supposed to have a start and a finish.  The
starting vertex is always 0.  The final vertex is the last one added.
A vertex can have any content (besides its number and its links).

Throughout this documentation the classic term I<vertex> is sometimes
exchanged (or accompanied) with terms item, node, point as synonim.
Another classic term I<edge> is sometimes exchanged with the term
link.

=cut

####  The object properties, methods and structure: 
####     methods:
####     Graph-building methods:
####         add_item
####         add_link
####         add_links

####   NAVIGATION
####         alternatives ()          -  successors of the current node
####         move_to ( ITEM_NUMBER )  -  content

####   TEST
####         final_reachable  ???
####         final

###  !!!   right theese final-related are left to implement

####   ACCESSORS
####         vars_items
####         vars_current

####         get_item



#####
#####  NEW (constructor)
#####

=head2 GRAPH CREATION METHODS

=over 4

=item  * new ()

Creates new empty graph (with only one starting vertex).

=cut

sub new {

    my $type = shift;
    
    my $self = [
		[ ],   ### items data
		[ ],   ### links (successor)
		[ ],   ### current position and other variables
		];

    bless $self, $type;

    $self->vars_items ( -1 );

    $self->add_item ( 0 );

    $self->vars_current ( 0 );

    return $self;
}


#### ITEM (VERTEX) CREATION

=item  * add_item ( ARRAY )

This method will add a vertex to the graph and all arguments will be
treated as its content and will be returned once you I<move_to> this
particular vertex (or item, or node).

=cut

sub add_item {
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    my @item_data = @_; assert( scalar @item_data ) if DEBUG;
    
    my $i = push @$items, \@item_data;
    push @$links, [];
    
    $self->vars_items ( $self->vars_items + 1 );

    return $i-1;
}


### LINKING METHODS (EDGES)

=item * add_link ( SOURCE, TARGET )

Creates an edge (directed) from SOURCE to TARGET, both of which are
integer numbers, representing existing vetices (items).

=cut

sub add_link {
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    my $link_src = shift; assert( defined $link_src ) if DEBUG;
    my $link_trg = shift; assert( defined $link_trg ) if DEBUG;

    push @{$links->[$link_src]}, $link_trg;
}

=item * add_links ( SOURCES, TARGETS )

This method creates a link or multiple links between vertices.  Both
arguments can be integers (vertex indices) or array references
(independently of each other).  In the array reference case the array
shall consist of integer vertex indices to be used as link source or
target respectively.

=cut

sub add_links {
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    my $srcs = shift; assert( defined $srcs ) if DEBUG;
    my $trgs = shift; assert( defined $trgs ) if DEBUG;

    if ( ref( $srcs ) eq 'ARRAY' ) {
	foreach (@$srcs) {
	    $self->add_links ( $_, $trgs );
	}
    } else {
	assert( not ref( $srcs ) );
	if( ref ( $trgs ) eq 'ARRAY' ) {
	    foreach ( @$trgs ) {
		$self->add_link ( $srcs, $_ );
	    }
	} else {
	    assert( not ref( $trgs ) );	
	    $self->add_link ( $srcs, $trgs );
	}
    }
}

#####  GRAPH NAVIGATION METHODS

=back

=head2 GRAPH NAVIGATION METHODS

=over 4

=item * alternatives (  [ SCALAR ]  )

Returns a list of vertices (numbers) accessible from the current or
the specified position (or vertex, node, item).

=cut 

sub alternatives {
    my $self = shift;      assert ( $self ) if DEBUG;

    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];
                                                       
    my $cur = shift || $self->vars_current();
    return @{$links->[$cur]};
}

=item * move_to ( SCALAR )

Changes current position to a vertex of the number SCALAR and returns
its content (as array).

=cut

sub move_to {
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    my $destination = shift; assert( $destination ) if DEBUG;

    my $cur = $self->vars_current();
    my $alt = $links->[$cur];
    
    my $correct;
    foreach ( @$alt ) {
	if ( $destination == $_ ) {
	    $correct = 1; 
	    last;
	}
    }
    if (not $correct) {
	return undef;
    }
    $self->vars_current( $destination );
    
    return @{$items->[$destination]};
}


=item * reset ( ) 

Resets current navigated graph position to the initial vertex.

=cut

sub reset {
    my $self = shift;      assert ( $self ) if DEBUG;
#     my $items = $self->[0];
#     my $links = $self->[1];
#     my $vars  = $self->[2];

    $self->vars_current( 0 );
    
    return;
}

=back

=head2 GRAPH DATA RETRIEVAL AND TESTS METHODS

=over 4

=item * get_item ( SCALAR )

Returns the content of a vertex by the number SCALAR.

=cut

sub get_item {
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    my $item_no = shift; assert ( $item_no ) if DEBUG;

    return @{$items->[$item_no]};
}

=item * get_item_ref ( SCALAR )

Returns a reference to the content (ARRAY) of a vertex by the number SCALAR.

=cut

sub get_item_ref {
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    my $item_no = shift; assert( $item_no ) if DEBUG;

    return $items->[$item_no];
}


###  FINAL-POINT TESTS 

=item * final_reachable ( )

Returns true if the graph's final vertex (the last one added) is
accessible from the current vertex (by one direct edge).

=cut

sub final_reachable {
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];
    
    my $final = $self->vars_items;
    
    my @alt = $self->alternatives;
    
    my $result ;
    foreach ( @alt ) {
	if ( $final == $_ ) {
	    $result = 1 ;
	    last;
	}
    }
    return $result;
}


###  SUB FINAL 

=item * final ( ) 

Returns the number of the last vertex (node or item).

=cut

sub final {
    my $self = shift;
    return $self -> vars_items();
}

###  INTERNAL ACCESSOR METHODS

sub vars_items {     ##### NUMBER OF THE GRAPH NODES
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    if ( scalar @_ ) { $vars->[0] = shift ; } 
    else             { return $vars->[0];   }
} 


sub vars_current {    #### CURRENT GRAPH NODE
    my $self = shift;      assert ( $self ) if DEBUG;
    my $items = $self->[0];
    my $links = $self->[1];
    my $vars  = $self->[2];

    if ( scalar @_ ) { $vars->[1] = shift ; } 
    else             { return $vars->[1];   }
} 

=back

=head1 SEE ALSO

Graph, Graph::Directed modules from the book I<Mastering Algorithms
with Perl> by Jon Orwant, Jarkko Hietaniemi & John Macdonald from
O'Reilly, and the whole Chapter 8.

=head1 AUTHOR

Ivan Kurmanov <ivan@tm.minsk.by>, <iku@fnmail.com>

=cut


1;



