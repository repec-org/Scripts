package RePEc::Find;

=pod 

=head1 NAME

RePEc::Find package

=head1 SYNOPSIS

package Processor;

sub start_redif_dir {
    ...
}

sub end_redif_dir {
}

sub redif_file {
}

sub warning {
}

sub error {
}

my $dir = '/home/ivan/data/RePEc';
my $P = {};
bless $P, 'Processor';
RePEc::Find::traverse_directory( $dir, $P );

=cut


use File::Find;
use strict;

use vars qw( %DIR );

#####################################################################

sub traverse_directory {
    my $dir = shift;
    my $processor = shift;
    
    $processor -> start_redif_dir ( $dir );

    if( not -d $dir ) {
	$processor -> error ( "Bad directory name: $dir" ) ;
    }
    
    my $handler = sub {
	report_any_redif_file_found( $processor, @_ ) ;
    };

    $DIR{$processor}{dir} = $dir;
    $DIR{$processor}{short} = undef;
    $DIR{$processor}{full}  = undef;
    $DIR{$processor}{counter} = {};

    ### find!
    find ( $handler, "$dir" );
    
    $processor -> end_redif_dir( $dir, $DIR{$processor}{counter} );

    delete $DIR{$processor}; 
}



#####################################################################


sub report_any_redif_file_found {

    my $processor = shift;
    my $dir = $DIR{$processor}{dir};
    
    if (/\.rdf$/i) {
	
	my $fname = $File::Find::name;   
	
	$DIR{$processor}{counter}{files} ++;
	
	my $short_filename; 
	
	if ( $fname =~ /^$dir(?:\/)?(.+)/ ) {
	    $short_filename = $1; 
	}

	if ( not $short_filename ) {
	    $processor -> warning (
				   "Can't produce short filename" .
				   " from full name: $File::Find::name" );
	    $fname =~ /\/([a-z]{3}\/.+)/i;
	    $short_filename = $1;
	}
	
	$DIR{$processor}{short} = $short_filename; 
	$DIR{$processor}{full} = $fname; 
	
	$processor -> redif_file( $fname, $short_filename );
    }
}


#########################################################################################

1;

__END__


