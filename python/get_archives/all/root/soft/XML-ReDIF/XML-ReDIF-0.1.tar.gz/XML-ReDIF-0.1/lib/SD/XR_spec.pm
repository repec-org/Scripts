package SD::XR_spec;

### Package for XML-Redif-spec parsing

BEGIN { $Devel::Assert::DEBUG = 1 ; }
use Devel::Assert ':DEBUG';

use strict;

use SD::Input;
use SD::Doc;

### $SD::Doc::DEBUG = 1;

############################  BUILDING  ##########################
#########################  XML-ReDIF-spec  #######################
############################    spec    ##########################

use SD::SType;
use pretty_print;

use vars qw( $XR_spec  $XR_spec_DT );

use subs qw( &initialize_XR_spec );

initialize_XR_spec ( );

###

sub initialize_XR_spec {

    my $DT = SD::DocType -> make_doc_type ( 'ReDIF-spec' );
    
    $XR_spec_DT = $DT;    ### XML-ReDIF sd::DocType
    
### use SD::ReDIF;
### use SD::ReDIF::Template;
### $SD::Machine::DEBUG = 1;

    my $R = $DT -> stype;

    $R -> doctype_class ( 'SD::Doc::XR_spec' );

    $R -> make (  name => 'string', 
		  content => 'cdata',
		  cdata => 
		  { valtype => 'free' },
		  );
    
#   $R -> make (  name => 'non-empty-string', 
#		  content => 'cdata',
#		  cdata => 
#		  { value => '\w\d+' },
#		  );
    
    $R -> make (  name => 'non-empty-string', 
		  content => 'cdata',
		  cdata => 
		  { valtype => 'free',
		    'non-empty' => 1, },
		  );
    
    my $NT = $R -> make ( 
			  name => 'ReDIF-spec',
			  content => 'element',
			  class => "SD::Doc::ReDIFspec",
			  type => 'choice',
			  element => [
#				      { name => 'template', },
#				      { name => 'cluster',  },
				      { name => 'type',     },
				      { name => 'datatype', },
#				      { name => 'method',   },
				      ],
			  );

#    $R -> make (  name =>    'template', 
#		  content => 'element',
#		  type =>    'seq',
#		  element => [], );
#
#    $R -> make (  name =>    'cluster', 
#		  content => 'element',
#		  type =>    'seq',
#		  element => [], );
#    $R -> make (  name =>    'datatype', 
#		  content => 'element',
#		  type =>    'seq',
#		  element => [], );
#    
#    $R -> make (  name =>    'method', 
#		  content => 'element',
#		  type =>    'seq',
#		  element => [], );


    my $type_elem = [
		     {
			 name => 'explain', 
			 type => 'string',
			 occurs => '?'  ,
		     },
		     { 
			 choice => 1,
			 1 => { name => 'cdata',      }, 
			 2 => { name => 'sequence',   }, 
			 3 => { name => 'pool',       },
			 occurs => '1',
		     }, 
		     { 
			 name => 'class', 
			 type => 'non-empty-string',
			 occurs => '?',
		     },
		     ];
    
    my $t =    $R -> make (  name    => 'type', 
			     content => 'element',
			     type    => 'seq',
			     class   => 'SD::Doc::TYPE',
			     element => $type_elem, );

    $R -> make (  name =>    'element', 
		  content => 'element',
		  type =>    'seq',
		  element => [],
		  options => { ignore_ws => 0 } , );

    $R-> make ( name => 'cdata' , 
		content => 'element',
		type => 'choice',
		element => [
			    {
				name => 'RE',
				type => 'string',
				occurs => '?',
			    }, 
			    ],
		);
    
    my $elems = [ { name=> 'element', occurs => '*' } ];
    
    $R -> make (  name =>    'sequence', 
		  content => 'element',
		  type =>    'seq',
		  element => $elems, );
    
    $R -> make (  name =>    'pool', 
		  content => 'element',
		  type =>    'seq',
		  element => $elems, );



    my $dt =    $R -> make (  name    => 'datatype', 
			      content => 'element',
			      extends => 'cdata',
			      class   => 'SD::Doc::DTYPE',
			      type    => 'choice',
			      element => [ 
					  { name => 'explain', 
                                            type => 'string' },
					  { name => 'class', 
                                            type => 'string' }
					   ],
			     );

    
    my $res = $DT -> produce_structure;
    
    print "XR-spec reading preparation: ", ( $res ? 'OK' : 'FAILED' ), "\n";
    
    $XR_spec = $res;   ### XML-ReDIF spec
    
    return $res;
}




############################   <datatype>   ##################################

package SD::Doc::DTYPE;


use vars '@ISA';
@ISA = ( 'SD::Doc' );


use vars qw( %REG );


sub open {
    my $self = shift;
    my $mach = shift;
    my $event = shift;

    my $attrs = $event->data2;

    $self->data ( {} );
    my $data = $self->data ;
    
    if( not defined $attrs -> {ID}  or 
	( $attrs -> {ID} !~ /^[A-Za-z][\w\d\_\-]+$/ ) ) {
	$mach -> error ( 'Need a valid ID attribute' ) ;
    } else {
	if ( $SD::Doc::TYPE::REG{$attrs->{ID}} ) {
	    $mach -> error ( "A type of this name (", $attrs->{ID},
			     ") has already been defined" ) ;
	} else {
	    $REG{$attrs->{ID}} = 1;
	    $SD::Doc::TYPE::REG{$attrs->{ID}} = 1;
	    $data -> {name} = $attrs->{ID};
	}
    }

    if( defined $attrs -> {base} ) {
	$mach -> error ( "The datatype subclassing is not yet supported" );
	
    }

    $self -> SUPER::open ( $mach, $event, @_ );
};


sub success {
    my $self = shift;
    my $mach = shift;

    my $contents = $self -> contents;
    my $data =     $self -> data;

#    my $CM = $contents->[2];
    my $CM = $contents;
    $self->build_cdata ( $CM );

#    use pretty_print;
#    pretty_print( "THE DATATYPE MAKE: ", $data );

    $SD::XR::ROOT -> make ( %$data );
}



sub build_cdata {
    my $self = shift;
    my $cdata = shift;

###    print " build_cdata: $cdata\n" , @$cdata ;
    
    my $data = $self->data;

    $data -> {content} = 'cdata';
    my $res = {};
    $data -> {cdata} = $res;
    
    my $i = 2; my $c;
    while ( $c = $cdata ->[$i] ) {
	if ($c->[0] eq '<RE>') {
	    $res->{value} = $c->[2];
#	    print "CDATA : RE : ", $c->[2], "\n";
	} elsif ( $c->[0] eq '<enumeration>' ) {   #### !!!!!
	} elsif ( $c->[0] eq '<list>' ) {
	} elsif ( $c->[0] eq '<explain>') {
	    $data->{description} = $c->[2];
	} elsif ( $c->[0] eq '<class>') {
	    $data->{class} = $c->[2];
	}
	$i++;
    }

    if ( not $res->{value} ) {
	$res -> {valtype} = 'free';
    }

    if ( exists $cdata->[1]->{'non-empty'} ) { 
	$res -> {'non-empty'} = $cdata->[1]->{'non-empty'} ;
    }
 
    ########################  !!!!!!!!!!!!!!
    ####  WHY NON-EMPTY=0 DOESN'T WORK ??!  

    
}


##############################   <type>   ####################################

package SD::Doc::TYPE;


use vars '@ISA';
@ISA = ( 'SD::Doc' );


use vars qw( %REG );


sub open {
    my $self = shift;
    my $mach = shift;
    my $event = shift;

    my $attrs = $event->data2;

    $self->data ( {} );
    my $data = $self->data ;
    

    if( not defined $attrs -> {ID}  or 
	( $attrs -> {ID} !~ /^[A-Za-z][\w\d\_\-]+$/ ) ) {
	$mach -> error ( 'Need a valid ID attribute' ) ;
    } else {
	if ( $REG{$attrs->{ID}} ) {
	    $mach -> error ( "A type of this name (", $attrs->{ID},
			     ") has already been defined" ) ;
	} else {
	    $REG{$attrs->{ID}} = 1;
	    $data -> {name} = $attrs->{ID};
	}
    }

    if( defined $attrs -> {base} ) {
	if ( not $REG{$attrs->{base}} ) {
	    $mach -> error ( "The base type ('", $attrs->{base}, 
			     "') must have already been defined" ) ;
	} else {
	    $data -> {extends} = $attrs->{base};
	}
    }

    $self -> SUPER::open ( $mach, $event, @_ );
};




sub success {
    my $self = shift;
    my $mach = shift;

    my $contents = $self -> contents;
    my $data =     $self -> data;

    my $i = 2; my $c;
    while ( $c = $contents->[$i] ) {
	my $CM = $contents->[$i];

	if ( $CM->[0] eq '<pool>' ) {
   
	    $self->build_pool (  $CM ) ;
	    
	} elsif( $CM->[0] eq '<sequence>'  ) {
	    
	    $self->build_sequence ($CM );
	    
	} elsif ( $CM->[0] eq '<cdata>') {
	    
	    $self->build_cdata ( $CM );
	    
	} elsif ( $CM->[0] eq '<options>') {
	    
	} elsif ( $CM->[0] eq '<class>') {
	    $data->{class}       = $CM->[2];
###	    print "CLASS element: >", $CM->[2], "<\n";
	} elsif ( $CM->[0] eq '<explain>') {
	    $data->{description} = $CM->[2];
###	} elsif ( $CM->[0] eq '<options>') {
	}
	$i++;
    }

#    use pretty_print;
#    pretty_print( "THE TYPE MAKE: ", $data );

    $SD::XR::ROOT -> make ( %$data );
    
}



sub build_cdata {
    my $self = shift;
    my $cdata = shift;
    
    my $data = $self->data;

    $data -> {content} = 'cdata';
    my $res = {};
    $data -> {cdata} = $res;
    
    my $i = 2; my $c;
    while ( $c = $cdata ->[$i] ) {
	if ($c->[0] eq '<RE>') {
	    $res->{value} = $c->[2];
#	    print "CDATA : RE : ", $c->[2], "\n";
	} elsif ( $c->[0] eq '<enumeration>' ) {   #### !!!!!
	} elsif ( $c->[0] eq '<list>' ) {
	}
	$i++;
    }

    if ( $i == 2 ) {
	$res -> {valtype} = 'free';
	if ( $cdata->[1]->{'non-empty'} ) { 
	    $res -> {'non-empty'} = $cdata->[1]->{'non-empty'} ;
	}
    }
}



sub build_sequence {
    my $self = shift;
    my $seq = shift;

    my $data =     $self -> data;

    $data -> {content} = 'element';
    $data -> {type}    = 'seq';

    my $elements = [];
    $data -> {element} = $elements;

    my $attrs = $seq->[1]; ###  <seq>

    my $i = 2;
    my $el;
    while ( $el = $seq->[$i] ) {
	push @$elements, make_element( $el );
	$i++;
    }
}



sub build_pool {
    my $self = shift;
    my $pool = shift;

    my $data =     $self -> data;

    $data -> {content} = 'element';
    $data -> {type}    = 'choice';

    my $elements = [];
    $data -> {element} = $elements;

    my $attrs = $pool->[1]; ###  <pool>

    my $i = 2;
    my $el;
    while ( $el = $pool->[$i] ) {
	push @$elements, make_element( $el );
	$i++;
    }
}


sub make_choice {}

sub make_element {
    my $el = shift;

    if ( $el->[0] eq '<choice>' ) { return make_choice ( $el ); }
    if ( $el->[0] ne '<element>' ) { return undef; }
    
    my $ats= $el->[1];
    my $res = {};

    if ( $ats->{name} ) { $res->{name}     = $ats->{name} ;   }
    if ( $ats->{type} ) { $res->{type}     = $ats->{type} ;   }
    if ( $ats->{occurs} ) { $res->{occurs} = $ats->{occurs} ; }

    if ( $ats->{min} ) { $res->{min}       = $ats->{min} ; }
    if ( $ats->{max} ) { $res->{max}       = $ats->{max} ; }

    return undef if not $res->{name};
    return ( $res );
}


###########################   redif-spec.xml   ################################

package SD::Doc::XR_spec;

use pretty_print;
use vars '@ISA';
@ISA = ( 'SD::Doc' );

use SD::SType;

sub open {
    my $self = shift;

    $self->data( {} );

    my $DT = SD::DocType -> make_doc_type ( 'ReDIF' );

    $SD::XR::DT = $DT;
    $SD::XR::ROOT = $DT->stype;

    $self->data->{DT} = $DT;
    $self->data->{ROOT} = $DT->stype;
    my $R = $self->data->{ROOT} ;

    $R -> make (  name => 'string', 
		  content => 'cdata',
		  cdata => 
		  { valtype => 'free' },
		  );
    
    $R -> make (  name => 'non-empty-string', 
		  content => 'cdata',
		  cdata => 
		  { valtype => 'free',
		    'non-empty' => 1, },
		  );
    

    $self->SUPER::open ( @_ );
}

sub close {
    my $self = shift;
    my $mach = shift;
    my $input = shift;
    my $success = shift;
    
    my $spec = $self-> data -> {spec} ;

    $self->contents ( $spec );

#    print "Finished reading spec file (", 
#    $success ? 'success' : 'fail'
#	, ").\n";
#    pretty_print ( $spec );


#    $self->data->{ROOT}
#    -> make (  name => 'ReDIF', 
#	       content => 'element',
#	       type => 'choice',
#	       element => [
#			
#			],
#	       );
#

    $SD::XR::STRUCT = $self->data->{DT} -> produce_structure;
    
#    $self->contents ( $self->data->{DT} );
    $self->contents ( 1 );

    return 1;

};


sub element {
    my $self = shift;
    my $mach = shift;
    my $element = shift;  

    if ( ( $element -> type ) =~ /redif.?spec/i ) {
	$self->data->{spec} = $element->contents;
    } else {
	$self->SUPER::element ( $mach, $element );
    }
}



############################    <ReDIF-spec>    ###############################

package SD::Doc::ReDIFspec;


use vars '@ISA';
@ISA = ( 'SD::Doc' );

sub open {
    my $self = shift;
    my $mach = shift;
    my $event = shift;

    if( not defined $event->data2->{version}  or 
	( $event->data2->{version} !~ /^\d+.\d+/ ) ) {
	$mach -> error ( 'Need version attribute' ) ;
    } else {
	print " - using XR-spec of version: '" , 
	$event->data2->{version}, "'\n";
    }

    if( not defined $event->data2->{ReDIF}  or 
	( $event->data2->{ReDIF} !~ /^\d+.\d+/ ) ) {
	$mach -> error ( 'Need ReDIF attribute' ) ;
    } else {
	$SD::XR::Rversion  = $event->data2->{ReDIF};
	print " - target ReDIF version: '" , 
	$SD::XR::Rversion,
	"'\n";
    }

    $self->SUPER::open ( $mach, $event, @_ );
};


################################   the end   ##################################


__END__

package SD::Doc::1;

use vars '@ISA';
@ISA = ( 'SD::Doc' );

sub {};



package SD::Doc::2;

use vars '@ISA';
@ISA = ( 'SD::Doc' );

sub {};





