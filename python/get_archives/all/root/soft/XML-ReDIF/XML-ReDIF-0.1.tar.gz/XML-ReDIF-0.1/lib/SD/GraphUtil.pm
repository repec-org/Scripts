
package SD::GraphUtil;

use SD::Graph;

##############################################################################
###  This package is a supplement to SD::Graph module. 
###
###  It will contain some additional Graph-related routines to support 
###  Graph creation and usage.
##############################################################################


use Devel::Assert ':DEBUG';

sub visualize_graph {
    my $graph = shift;

    print "The Graph: $graph\n";

    my $c ;
    for ( $c =0 ; $c <= $graph->final ; $c++ ) {

	
	print  "$c" ;
	if ($c) {
	    print " [ ", join ( ", " , $graph->get_item($c) ) , " ]" ; 
	}
	print ": ";

	my @links = $graph -> alternatives ( $c );

	my $t;
	foreach ( @links ) { 
	    print "$t$c -> $_"; 
	    $t = " | ";
	}
	print "\n";
    }

}


####   Content model building subroutine:
####
### ##########################
###  S U B    M O D E L 
### ##########################
####
####  INPUT  SYNTAX:    -> model( MODEL, OCCURS );

####  where MODEL is smth. like these:
####  [ 'sec', "A", "", "B", "" , [ 'alt' , "E" , "D" ] , "?" ],;

####  While OCCURS is one of the [+?*1] or is empty.

sub model {

    my $item = shift;
    my $occur = shift;

    my $graph = SD::Graph -> new ;

    my ( $ends, $st ) = 
	add_content_item ( $graph, [ 0 ], $item, $occur );

    my $final = $graph -> add_item ( -1 ) ;

###    print "ENDS: ", join( ' ', @$ends ) , "\n";

    $graph->add_links ( $ends, $final );

    return $graph;

}

######    MODEL, the end of


######
######    A D D   C O N T E N T   I T E M 
######

sub add_content_item { 
    my $graph  = shift;

    my $link_to = shift;
    my $item  = shift;
    my $occur = shift;

    my $gr = $graph;

    my $item_start = $link_to;
    my $item_end ;


           ######### 
           #########      SCALAR ITEM ELEMENTS TREATMENT
           ######### 

    if ( ref( $item ) ne 'ARRAY' ){

	my $it = $graph -> add_item ( $item );

	$graph -> add_links ( $link_to, $it );

	$item_start = [ $it ];

	if ( defined $occur ) {
	    my $s = '' ; my $e = '';

	    #####   OCCURS SPECIFICATION PROCESSING: 
	    #####   BUILDING APPROPRIATE GRAPH STRUCTURE

	    if ($occur eq '+') {        #####  ONE OR MORE  
		
		$graph -> add_link ( $it, $it ); ###  (repeatable)
		$link_to = [ $it ];             ###  (required)
		
	    } elsif ( $occur eq '?' ) { #####  ZERO OR ONE  

		push @$link_to, $it;            ###  (optional)

	    } elsif ($occur eq '*') {   #####  ZERO OR ANY POSITIVE NUMBER 

		$graph -> add_link ( $it, $it ); ###  (repeatable)
		push @$link_to, $it;            ###  (optional)

	    } else {                    #####  DEFAULT: required 1 occurence

		$link_to = [ $it ];             ###  (required)

	    }
	} else {                        #####  same as previous: DEFAULT

	    $link_to = [ $it ];                 ###  (required)

	}

	return ( $link_to, $item_start );

    } else {
	
	my $index = 0;
	my $mode = $item->[$index++];
	
           ######### 
           #########     ORDERED  SEQUENCE  TREATMENT
           ######### 

	if ( $mode eq 'seq' ) {

	    my $first ; my $f; my $chain = $link_to;

	    while ( $index <= $#$item ) { ### while some items are left
		
		my $it = $item->[$index++];
		my $o = $item->[$index++];
		
		( $chain, $f )
          		    = add_content_item ( $graph, $chain, $it, $o );
		if( not defined $first ) {
		    $first = $f;
		}
	    }
	    
	    $item_start = $first;
	    $item_end = $chain;
	    
	} elsif ( $mode eq 'alt' ) {

           ######### 
           #########      CHOICE  TREATMENT
           ######### 

	    my $starts = [];
	    my $ends = [];

	    while ( $index <= $#$item ) { ### while some items are left
		
		my $it = $item->[$index++];
		my $o = $occur;
		
		my ( $end, $start ) =
		             add_content_item ( $graph, $link_to , $it );
		assert( $end ) ;
		push @$ends, @{$end};
		push @$starts, @{$start};
	    }

	    $item_start = $starts;
	    $item_end   = $ends;

	} else {
	    use Carp;
	    confess ( "Bad model specification : need a mode specifier '$mode'" );
	}
    }
    
    if ( defined $occur ) {
	my $s = '' ; my $e = '';
	if ($occur eq '+') {     #####  ONE OR MORE

	    $graph -> add_links ( $item_end , $item_start );

	    $link_to = $item_end ;                ### (required)

	} elsif ( $occur eq '?' ) {  ###  ZERO OR ONE

	    push @$link_to, @$item_end;           ### (optional)

	} elsif ($occur eq '*') { #####  ZERO OR ANY POSITIVE NUMBER

	    $graph -> add_links ( $item_end , $item_start );

	    push @$link_to, @$item_end;          ### (optional) 

	} elsif ( $occur eq '1' 
		  or $occur eq '' ) {  ####  EXACTLY ONE TIME OCCUR

	    $link_to = $item_end;                ### (required)

	} else {
	    die "Bad OCCURS flag: <$occur>"; 
	}

    } else {                        ####  EXACTLY ONE TIME OCCUR

	$link_to = $item_end ;                   ### (required)

    }

    return ( $link_to, $item_start );
}

########  end of  ADD CONTENT ITEM 

package SD::Graph;
1;
