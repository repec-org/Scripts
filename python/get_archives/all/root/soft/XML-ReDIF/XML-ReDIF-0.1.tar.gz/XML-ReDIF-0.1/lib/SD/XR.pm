package SD::XR;

### Package for XML-Redif-spec parsing

BEGIN { $Devel::Assert::DEBUG = 1 ; }
use Devel::Assert ':DEBUG';

use strict;

use SD::SuperM;
use SD::Input;
use SD::Doc;

### $SD::Doc::DEBUG = 1;

############################  BUILDING  ##########################
#########################  XML-ReDIF-spec  #######################
############################    spec    ##########################

use SD::SType;
use pretty_print;

use SD::XR_spec;

use vars qw( $XR_spec  $XR_spec_DT  $XR_DT $XR_ST  $XR_STR   );

my $XRSPECFILE;

sub import {

    return if $XRSPECFILE;
    my $class = shift;
    my $f = shift;
    $XRSPECFILE = $f || 'redif.spec.xml';
    die "File '$XRSPECFILE' doesn't exists" if not -e $XRSPECFILE;
    
    &init ();
}


sub initialize_XR_spec {

    use SD::XR_spec;
    
    assert( $SD::XR_spec::XR_spec );

    $XR_spec_DT = $SD::XR_spec::XR_spec_DT;  ### XML-ReDIF sd::DocType
    $XR_spec    = $SD::XR_spec::XR_spec;     ### XML-ReDIF spec language
    
    return $XR_spec;
}
    


sub read_XR_spec {    

    my $filename = shift;

    my $root = $XR_spec;  assert ( $root );
    
############################  BUiLDING  ##############################

    my $checker = \&SD::Input::input_event_condition_checker; 
    
    my $m = SD::SuperM -> new (
			       struct  => $root, 
			       checker => $checker,
			       );
    
# $SD::Machine::DEBUG = 1;
  
    print "Loading '$filename'...\n";
    
    SD::Input::start ( $filename, $m );
    
    my $result = $m -> result();
    
    print " - XML-ReDIF-spec intialization: ";
    print ( $result->[0] ? 'OK' : 'FAILED' ) ;
    print "\n";

    return $result->[1]->data->{DT}; 
}


sub init {

    &initialize_XR_spec();

    my $file = $XRSPECFILE ;

    assert( $file );

    my $rspec = &read_XR_spec ( $file );

#     pretty_print ( $rspec );

    die if not ref ( $rspec )  eq 'SD::DocType';

    $XR_DT = $rspec;
    $XR_ST = $XR_DT -> stype ;

    my $res = $XR_DT -> produce_structure;
    print " - XML-ReDIF parser initialization: ", 
                    ( $res ? 'OK' : 'FAILED' ), "\n";

    $XR_STR = $res;
    
    return $res;
}



sub read_file {

    my $filename = shift; 
    
    assert( $filename );
###    assert( -r $filename );
    if ( not -e $filename ) {
	warn "File $filename doesn't exists, so it can't be read" ;
	return undef;
    }

    my $root = $SD::XR::STRUCT;
    assert ( $root );
    
 ############################  READ DATA  ##############################

    my $checker = \&SD::Input::input_event_condition_checker; 
    
    my $m = SD::SuperM -> new (
			       struct  => $root, 
			       checker => $checker,
			       );
    
# $SD::Machine::DEBUG = 1;
# $file = '/home/ivan/devel/parser/data/test.redif.xml';

    print "\nREADING XR FILE: '$filename'\n";
    
    SD::Input::start ( $filename, $m );
    
    my $result = $m -> result();
    
    print "\n - OVERALL XML-ReDIF FILE RESULT: ";
    print ( $result->[0] ? 'OK' : 'FAILED' ) ;
    print "\n";

    return $result->[0]; 

}



1;


