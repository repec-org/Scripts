package ReDIF::Parser::Input;

##  Copyright (c) 1997-2001 Ivan Kurmanov. All rights reserved.
##
##  This code is free software; you can redistribute it and/or modify it
##  under the same terms as Perl itself.

$VERSION = '0.1';  ### $Id: Input.pm,v 1.25 2002/06/18 07:53:32 ivan Exp $

local $/;

use ReDIF::Unicode qw( &has_utf8_bom &utf8_from_latin1 );

use strict;

use vars qw( 
	     $BUFFER
	     $CURRENT_BUFFER_POSITION

	     $CURRENT_FILE_POSITION
	     $LINE_NUMBER

	     $SOURCE_ENCODING 
	     $PARSER_MODULE 
	     $FILENAME 

	     $Options 

	     %TEMPLATE_STARTERS
	     $TEMPLATE_CHECKSUM
	     
	     @LINES
	     );

%TEMPLATE_STARTERS = (
		      'template-type' => 1,
		      );

use constant DEBUG => 0;

$BUFFER = ' ' x 1000;
my $CHUNK_SIZE = 400; 

my $LINE_ENDING ;

my $THE_LINE = ' 'x 1000;
my $THE_LINE_ORIGINAL = ' 'x 1000;
my $THE_LINE_FILE_POSITION;
my $THE_LINE_BUFFER_POSITION;
my $THE_LINE_LENGTH;

my $eol_length;

my $EOF_STATUS;
my $ATTRIBUTE;

my $PARSING_STRING =0;
# $PARSER_MODULE = "ReDIF::ParserCore";


###  MD5 checksum calculations for templates

use ReDIF::setup_conf;

if( ReDIF::Parser::calculate_md5_checksum ) {
    require Digest::MD5;
    $TEMPLATE_CHECKSUM = Digest::MD5 -> new();
}

sub init {
    my $opt = shift;

    if( defined $opt ) {
	$Options = $opt;
    } else {
	$Options = {};
    }
}

sub start_file {
    
    my $filename = shift;
    my $pos = shift;

    if( (not -e $filename)
	or (not -r _ ) 
	or (not -f _ ) 
	) {
	return undef;
    }

    $PARSING_STRING = 0;
    $FILENAME = $filename;

    ####  A Check for non-standard line-termination

    close FILE;
    open FILE, "<$filename";
    binmode FILE;
    read FILE, $BUFFER, $CHUNK_SIZE;

    if ( $BUFFER =~ /\n/ ) { $/ = "\n"; }
    elsif ( $BUFFER =~ /\r/ ) { $/ = "\r"; }
    $LINE_ENDING = $/;
        
#    close FILE;
#    open FILE, "<$filename";
    
if(0){
    ###  line ending autodetection
    if ( $BUFFER =~ /[^\r\n]\n[^\r]/ )     { $LINE_ENDING = "\n"; }
    elsif ( $BUFFER =~ /[^\r\n]\r\n[^\r\n]/ ) { $LINE_ENDING = "\n"; }
    elsif ( $BUFFER =~ /[^\r\n]\n\r[^\r\n]/ ) { $LINE_ENDING = "\r"; }
    elsif ( $BUFFER =~ /[^\r\n]\r\n/ )        { $LINE_ENDING = "\n"; }
    elsif ( $BUFFER =~ /[^\r\n]\n\r/ )        { $LINE_ENDING = "\r"; }
    elsif ( $BUFFER =~ /[^\r\n]\r/ )          { $LINE_ENDING = "\r"; }
    else { $LINE_ENDING = "\n" ; }

# ( $BUFFER =~ /[^\r\n]\n\r[^\r\n]/ ) { $LINE_ENDING = "\r"; }
#    if    ( $BUFFER =~ /[^\r\n]\n[^\r]/ )     { $LINE_ENDING = "\n"; }
#    elsif ( $BUFFER =~ /[^\r\n]\r\n/ )        { $LINE_ENDING = "\r\n"; }
#    elsif ( $BUFFER =~ /[^\r\n]\n\r[^\r\n]/ ) { $LINE_ENDING = "\n\r"; }
#    elsif ( $BUFFER =~ /[^\r\n]\r/ )          { $LINE_ENDING = "\r"; }

    $eol_length = length ( $LINE_ENDING );

}

    $CURRENT_BUFFER_POSITION = 0;
    $CURRENT_FILE_POSITION   = 0;
    
    if( $pos ) {
	$FILENAME .= " (starting at $pos)";
	undef $LINE_NUMBER;
    } else {
	$pos = 0;
    }

    ###  UNICODE
    
    if( has_utf8_bom( $BUFFER ) ) {
	$SOURCE_ENCODING = "utf-8";
	$CURRENT_BUFFER_POSITION = 3;
	$pos = 3;
    } else {
	$SOURCE_ENCODING = "latin1";   
    }
    ####  

    $LINE_NUMBER = 0;

    seek (FILE, $pos, 0);
    $CURRENT_FILE_POSITION = $pos;
    $BUFFER = '' ;

    
    undef $THE_LINE;
    $EOF_STATUS = 0;
    
    return 1;
    
}


sub start_string {
    
    my $string = shift;

    close FILE;

    $PARSING_STRING = 1;
    $FILENAME = "buffer string";
    $BUFFER = $string;

    ###  UNICODE
    
    if( has_utf8_bom( $BUFFER ) ) {
	$SOURCE_ENCODING = "utf-8";
	substr( $BUFFER, 0, 3 ) = '';
    } else {
	$SOURCE_ENCODING = "latin1";   
    }
    ####  


    @LINES = split( /\n/, $BUFFER );

    $CURRENT_BUFFER_POSITION = 0;

    $LINE_NUMBER = 0;

    undef $THE_LINE;
    $EOF_STATUS = 0;
    
    return 1;
}



sub extract_next_line {
    return extract_next_line_self_sufficient();
}

sub extract_next_line_self_sufficient {

    undef $THE_LINE;
    undef $THE_LINE_LENGTH;
    undef $THE_LINE_BUFFER_POSITION;
    undef $THE_LINE_FILE_POSITION;

    
    if( not $PARSING_STRING ) {
	
	$THE_LINE_FILE_POSITION = tell( FILE );
	$THE_LINE = <FILE>;
	
	if( not defined $THE_LINE ) {
	    $EOF_STATUS = 1;
	    return undef;
	}

	$THE_LINE =~ s/\s+$//g;
#	chomp $THE_LINE;
#	chomp $THE_LINE;
	$THE_LINE_LENGTH = length( $THE_LINE );

    } else {

	$THE_LINE = shift @LINES;

	if( not defined $THE_LINE ) {
	    $EOF_STATUS = 1;
	    return undef;
	}

	$THE_LINE_LENGTH = length( $THE_LINE );
	$THE_LINE_FILE_POSITION = $CURRENT_BUFFER_POSITION;

	$CURRENT_BUFFER_POSITION += $THE_LINE_LENGTH + 1;

    }
	
    if( defined $LINE_NUMBER ) { $LINE_NUMBER++; }
    
    $THE_LINE_ORIGINAL = $THE_LINE;
    
    ###   UNICODE
    
    if( ( $SOURCE_ENCODING eq 'latin1' )  and $THE_LINE ) { 
	$THE_LINE = utf8_from_latin1 ( $THE_LINE );
    }
    
    return 1;


}



sub output_the_line {
    
    if( defined $Options->{output_source} ) {
	$Options->{output_source}-> add_data( "> $THE_LINE_ORIGINAL" );
    } 

    if( defined $Options->{output_source_utf8} ) {
	$Options->{output_source_utf8}-> add_data( "> $THE_LINE" );
    }    

    if( ReDIF::Parser::calculate_md5_checksum ) {
	if( $THE_LINE ) {
#	    if( not defined $TEMPLATE_CHECKSUM ) {
#		$TEMPLATE_CHECKSUM = Digest::MD5 -> new();
#	    }
	    $TEMPLATE_CHECKSUM -> add( $THE_LINE );
	    $TEMPLATE_CHECKSUM -> add( "\n" );
	    if( DEBUG ) {
		print "MD5: [ $THE_LINE ]\n";
	    }
	}
    }

}

sub extract_next_attribute {
    my $r;

    undef $ATTRIBUTE;
    my $send = 0;
    my $close_later = 0;

    while( 1 ) {

	if( not defined $THE_LINE ) {
	    $r = extract_next_line_self_sufficient ( ) ;

	    if( DEBUG ) {
		print " L\{ $THE_LINE \}\n";
	    }

	}
	
	if( defined $THE_LINE ) {
	    if ( $THE_LINE =~ /^\s*$/ ) {
		output_the_line();
		undef $THE_LINE;
		if( $EOF_STATUS ) { 
		    if(DEBUG){print" {EOF} ";} 
		    $close_later = 1; 
		    last;
		}
		next;
	    }

	    my ( $a, $v ) = $THE_LINE =~ /^([a-z\-]+):\s*(.+)?/i;

	    if( $a ) {

		###  Check for "template-type" attribute or equivalent

		if( $TEMPLATE_STARTERS{ lc( $a ) } 
		    and defined $ATTRIBUTE ) {
			
		    ###  then its a last attribute of 
		    ###  the previously read template

		    $close_later = 1;
		    last;

		} elsif( defined $ATTRIBUTE ) {
		    ###  send the attribute!
		    last;

		} 

		$ATTRIBUTE = {};
		$ATTRIBUTE->{file_position} = $THE_LINE_FILE_POSITION;
		if( defined $LINE_NUMBER ) {
		    $ATTRIBUTE->{line_number} = $LINE_NUMBER;
		}
		$ATTRIBUTE->{attribute} = $a;
		$ATTRIBUTE->{value} = $v ? $v : '';

		output_the_line();
		undef $THE_LINE;

	    } else {
		if( defined $ATTRIBUTE ) {
		    $ATTRIBUTE->{value} .= "\n";
		    $ATTRIBUTE->{value} .= $THE_LINE;
		    output_the_line();
		    undef $THE_LINE;

		} else {
		    $ATTRIBUTE = {};
		    $ATTRIBUTE->{file_position} = $THE_LINE_FILE_POSITION;

		    if( defined $LINE_NUMBER ) {
			$ATTRIBUTE->{line_number} = $LINE_NUMBER;
		    }
		    $ATTRIBUTE->{value} = $THE_LINE;
		    output_the_line();
		    undef $THE_LINE;
		    last;
		}
		    
	    }
	} else {
	    if( $EOF_STATUS ) {
		if(DEBUG) {print" [EOF] ";}
#		warn "EOF reached";
#		return undef;
	    }
	}

	if( $EOF_STATUS ) {
	    $close_later = 1;
	    last;
	}

    }  ### while (1) loop, upon the data lines

    if( defined $ATTRIBUTE ) {
	$ATTRIBUTE->{value} =~ s/\s+$//;
    }

    if( defined $Options->{attribute_output} ) {
	my $attr_out = $Options->{attribute_output};
	if( defined $ATTRIBUTE ) {	    
	    warn "sending '" . lc( $ATTRIBUTE->{attribute} ) . "' ..."
		if DEBUG;

	    if( $Options->{'remove_newline_from_values'} ) {
		$ATTRIBUTE->{value} =~ s/\s+/ /g;
	    }

	    ### FLUSH
	    $attr_out->the_attribute( lc $ATTRIBUTE->{attribute}, 
				      $ATTRIBUTE->{value}, 
				      $ATTRIBUTE->{file_position},
				      $ATTRIBUTE->{line_number}
				      );

	    if( defined $Options->{output_source} ) {
		$Options->{output_source}-> flush_data_buffer ();
	    } 
	    if( defined $Options->{output_source_utf8} ) {
		$Options->{output_source_utf8}-> flush_data_buffer ();
	    }    

	}
    }

    if( not defined $ATTRIBUTE ) {
#	if( defined $Options->{attribute_output} ) {
#	    warn "closing template (2)"
#		if $DEBUG;
#	    my $attr_out = $Options->{attribute_output};
#	    $attr_out-> close_current_template ();
#	}
	return undef;
    }

    if( $close_later ) {

	if( defined $Options->{attribute_output} ) {
	    warn "closing template (2)"
		if DEBUG;
	    my $attr_out = $Options->{attribute_output};
#	    $attr_out-> close_current_template ( 1 );
	    if( ReDIF::Parser::calculate_md5_checksum ) {
		my $digest = $TEMPLATE_CHECKSUM->b64digest;
		$attr_out-> close_current_template ( $digest );
		if( DEBUG ) {
		    print "MD5: " , $digest, "\n";
		}
#		undef $TEMPLATE_CHECKSUM ;
	    } else {
		$attr_out-> close_current_template ( 0 );
	    }
	}
    }

    return $ATTRIBUTE;
}




sub process_file {
    my $filename = shift;
    my $position = shift; 
    my $eof_reached = 0;

    my @LINES;

    start_file ( $filename, $position ) or return undef;
    
    while( 1 ) {
	while( 1 ) {
	    my $got_line = extract_next_line_self_sufficient ( );
	    my $pos = $THE_LINE_FILE_POSITION;
	    if( not $got_line ) {
		last;
	    }
	    my $line = { text   => $THE_LINE       , 
			 length => $THE_LINE_LENGTH,
			 pos => $pos
			 };

	    push @LINES, $line;
	}
	if( $EOF_STATUS ) { last; }
#	$eof_reached = not get_more_data_to_the_buffer ( );
    }
    
    close FILE;
    return( $EOF_STATUS,  [ @LINES ] );
}


sub get_line_ending { return $LINE_ENDING ; }
sub get_the_line    { return $THE_LINE ; }
sub get_the_line_length { return $THE_LINE_LENGTH ; }



sub self_test_extract_next_line {
    my $file_name = shift;
    my $enc = shift;
    my $line_lengths = shift;

    my @results ;
    
    start_file( $file_name );
    push @results, 
        $LINE_ENDING, 
        defined( $CURRENT_BUFFER_POSITION ), 
        defined( $CURRENT_FILE_POSITION ), 
        defined( $SOURCE_ENCODING ), 
        

    

}

1;
