#!/usr/bin/perl

#
#  This module is obsolete now ...
#

1;
