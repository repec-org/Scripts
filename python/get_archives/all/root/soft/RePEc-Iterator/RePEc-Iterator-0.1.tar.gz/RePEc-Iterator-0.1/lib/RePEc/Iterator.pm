#!/usr/bin/perl

# Oroginally created: March 4th, 2000, Ivan Kurmanov
#

package RePEc::Iterator;

###   This package is a tool for RePEc/ReDIF-developers.  It helps to
###   build applications which work on the whole RePEc/ReDIF dataset,
###   like rewe, for example.  This module when given a ReDIF root
###   directory, can traverse the dataset, archive by archive,
###   starting with the infrastructure files (e.g. XXXarch.rdf,
###   XXXseri.rdf, XXXmirr.rdf), and then finding all ReDIF data-files
###   of the archive.  This module uses Events module for a convenient
###   call-back system.  


$VERSION = "0.1";

use Events;


# use Carp::Assert (':NDEBUG');
# sub DEBUG {};


use File::Find;

& prepare( );

sub prepare {

    Events -> register_event ( 'REDIF::ARCHIVE::STARTED' );
    Events -> register_event ( 'REDIF::ARCHIVE::FINISHED' );
    Events -> register_event ( 'REDIF::FILE::NORMAL' );
    Events -> register_event ( 'REDIF::FILE::ARCHIVE' );
    Events -> register_event ( 'REDIF::FILE::SERIES' );
    Events -> register_event ( 'REDIF::FILE::MIRROR' );

    Events -> register_event ( 'REPEC::ITERATOR::ERROR' );
    Events -> register_event ( 'REPEC::ITERATOR::WARNING' );
    Events -> register_event ( 'REPEC::ITERATOR::MESSAGE' );

}

###################################
###################################
###################################

use strict;

use vars qw( 
	     $redif_remo_dir
	     $redif_all_dir

	     $authority
	     $archive
	     $archive_id
	     @ARCHIVES

	     $file
	     $file_name_short 

	     $archive_files_counter 
	     );

sub p {
    Events -> REPEC::ITERATOR::MESSAGE ( join '', @_ );
}

sub e {
    Events -> REPEC::ITERATOR::ERROR ( join '', @_ );
}

sub w {
    Events -> REPEC::ITERATOR::WARNING ( join '', @_ );
}



my ( $the_dir );
my ( $archives_counter );

sub main {

    my $redif_dir   = shift;
    $authority      = shift;
    $redif_remo_dir = "$redif_dir/remo";
    $redif_all_dir  = "$redif_remo_dir/all";
    
    $the_dir = "$redif_all_dir";

    p "Started looking for ReDIF in: '$the_dir'";

    opendir ( ALLDIR, $the_dir ) or 
	die "can't open the all '$the_dir' directory to read";

    my $dir_entry ;
    
  MAIN_LOOP:
    while ( $dir_entry = readdir ALLDIR ) {
	
	if ( $dir_entry =~ m|^([a-z]{3})arch\.rdf$|i ) {
	    
	    $archive_id = $1;
	    $archive    = "$authority:$1";
#	    assert ($archive_id);

	    {
		my $result = eval { 
		    Events -> REDIF::ARCHIVE::STARTED ( $archive ); 
		} ;
		&e ( $@ ) if $@;    
		if ( $@ or not $result ) {
		    Events -> REDIF::ARCHIVE::FINISHED ( '' );
		    next MAIN_LOOP;
		}
	    }

	    $archive_files_counter = 0;
	    
	    $file = "$the_dir/$dir_entry";
	    $file =~ s|//|/|g;

        my $original_file = $file;

	    $file = $redif_remo_dir . "\/$archive_id/$dir_entry";

	    $file =~ /^$redif_remo_dir\/(.+)$/ 
		or
		    die "File '$file' is not from the /remo/ dir";

	    $file_name_short = "$archive_id/$dir_entry";
	    
	    if (not -r $file) { 
		    e "File from all is not locally readable: $file";

            $file = $original_file;
    	    $file_name_short = "all/$dir_entry";
	    }

	    if (not -r $file) { 
		    e "File in all is not readable: $file";
		    Events -> REDIF::ARCHIVE::FINISHED ( '' );
		    next MAIN_LOOP;
	    }

	    ### here comes a call to the main code:

	    eval {
		&archive_file ( $file );
	    };
	    if ( $@ ) {
		&e( $@ );
	    }

	    $file =~ s/arch\.rdf/seri\.rdf/ ;
	    $file_name_short =~ s/arch\.rdf/seri\.rdf/ ;
	    $file =~ s/ARCH/SERI/ ;
	    $file_name_short =~ s/ARCH/SERI/ ;
	    

	    ### here comes another call to the processing code 

	    eval {
		&series_file ( $file ) ;
	    };
	    if ( $@ ) {
		&e( $@ );
	    }

	    $file =~ s/seri\.rdf/mirr\.rdf/ ;
	    $file_name_short =~ s/seri\.rdf/mirr\.rdf/ ;
	    $file =~ s/SERI/MIRR/ ;
	    $file_name_short =~ s/SERI/MIRR/ ;


	    ### here comes another call to the processing code 

	    eval {
		& mirror_file ( $file ) ;
	    };
	    if ( $@ ) {
		&e( $@ );
	    }

	    if ( not -e "$redif_remo_dir/$archive_id" ) {
		    Events -> REDIF::ARCHIVE::FINISHED ( '' );
		    next MAIN_LOOP;
	    }

	    ### now search for usual data files
               	    
	    eval {
		find ( \&redif_file_found, "$redif_remo_dir/$archive_id" );
	    };
	    if ( $@ ) {
		&e( $@ );
	    }

	    SECOND_BEST : {
		if ( not $archive_files_counter ) {
		    last SECOND_BEST
			if not -e "$redif_dir/$archive_id" ;
		    eval {
			find ( \&redif_file_found, "$redif_dir/$archive_id" ) ;
		    };
		    if ( $@ ) {
			&e( $@ );
		    }
		}
	    }


	    Events -> REDIF::ARCHIVE::FINISHED ( $archive_id );

	    $archive_id = '';

#	    p "Archive's files:\t$archive_files_counter\n";
	    
	} else {    
#	    print "rejected all/ entry: $dir_entry\n";
	}
    }

    p "Finished looking for ReDIF in: '$the_dir'";

}
#####################################################################

#####################################################################
## redif_file_found
#

sub redif_file_found {
   if ( 
	($File::Find::name =~ /${archive_id}seri\.rdf$/i ) or
        ($File::Find::name =~ /${archive_id}arch\.rdf$/i ) or
        ($File::Find::name =~ /${archive_id}mirr\.rdf$/i ) 
    )      
                                               {   return   }

   if (/\.rdf$/i) {
    
       my $fname = $File::Find::name;   

       $archive_files_counter ++;

       if ( $fname =~ /^$redif_remo_dir(?:\/)?(.+)/ ) {

            $file_name_short = $1; 

       } else {
 
            $fname =~ /\.\.\/(${archive_id}\/.+)/;
            $file_name_short = $1;
       }

       if ( not $file_name_short ) {
            &w (
       " Can't produce short filename from full name: $File::Find::name" );
            $fname =~ /\/([a-z]{3}\/.+)/i;
            $file_name_short = $1;
       }

       my $t = &process_file ( $fname, $file_name_short ) ;

   }
}


#####################################################################
## process_file
#

sub process_file {

    my $file = shift;
    my $file_name_short = shift;

    my $c = 
	Events -> REDIF::FILE::NORMAL ( $file, $file_name_short, $archive_id );

    return $c;
}

##################################################################
##  ARCHIVE_FILE
#

sub archive_file {

    my $file = shift;

#    print "Archive: $archive_id\n";

    push @ARCHIVES, $archive_id;
	    
    my $r = 
       Events -> REDIF::FILE::ARCHIVE ( $file, $file_name_short, $archive );
  
    return $r;
}

##################################################################
##  SERIES_FILE
#
sub series_file {

    my $file = shift;

    my $r = 
	Events -> REDIF::FILE::SERIES ( $file, $file_name_short, $archive_id );
    return $r;

}


##################################################################
##  MIRROR_FILE
#
sub mirror_file {

    my $file = shift;

    my $r = Events -> REDIF::FILE::MIRROR ( $file, $file_name_short, 
					    $archive_id );
    return $r;

}


1;
