package ReDIF::Parser;

BEGIN {
  eval { 
    require AMF::Parser; 
    require AMF::2ReDIF; 
    require ReDIF::Record;
  };
  if ( not $@ ) { $CAN_AMF = 1;  }
  else { $CAN_AMF = 0; undef $@; }

  if ( not defined &CAN_AMF ) {
    eval "use constant CAN_AMF => $CAN_AMF;";
    undef $@;
  }
}

1;
