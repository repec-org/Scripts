package SD::ReDIF;

use SD::Doc;

@ISA = ( 'SD::Doc' );

use Devel::Assert;

sub new {
    my $type = shift;

    my $self = $type-> SUPER::new ( @_ );
    $self->data ( 
		  {
		      stat =>	{ 
			  templates => {
			      all=> 0, 
			      valid => 0, 
			      invalid => 0, 
			      }
		      }
		  }
		      );
    return $self;
}


sub open {
    my $self = shift;
    my $mach = shift;
    my $element = shift;

    my $version ;
    assert ( $element );

    if ( not $element ->data2->{version} ) {
	$mach -> warning ( "Assuming ReDIF version '1.0'" );
	$version = '1.0';
    } else {
	$version = $element ->data2->{version};
    }

    $self->data->{version} = $version;
    if ( not $version eq $SD::XR::Rversion ) {
	$mach -> error ( "Wrong ReDIF version: '$version'" );
    }

    $self->SUPER::open($mach);
}




sub element { 
    my $self = shift;
    my $mach = shift;
    my $element = shift;
    my $valid = shift;
    
    my $v = $valid ? 'valid' : 'invalid' ;
    $self->data-> {stat}{templates}{all}++;
    $self->data-> {stat}{templates}{$v}++;
    $self->data-> {stat}{types}{$element->type}++;
}


sub close {
    my $self = shift;
    my $mach = shift;
    
    print "Finished XR file\n";
    print "\nStatistics: \n";
    print "\ttemplates (all)\t",  $self->data-> {stat}{templates}{all}, "\n";
    print "\t - valid  :\t",  $self->data-> {stat}{templates}{valid}, "\n";
    print "\t - invalid:\t", $self->data-> {stat}{templates}{invalid}, "\n";
    print "By template-type: \n";
    my $type_st =  $self->data-> {stat}{types};
    foreach ( keys %$type_st ) {
	print "\t - $_\t",  $type_st->{$_}, "\n";
    }
}











package SD::ReDIF::JEL;

@ISA = ( 'SD::Doc' );

# sub cdata {

sub cdata_strip {
    my $self    = shift;
    my $mach    = shift;
    my $text    = shift;

    my $value = $mach->event->data;

    $value =~ s/^\s+|\s+$//g;

    if ($value !~
	/[A-Za-z][0-9]{0,2}([,;:\.\s]+[A-Za-z][0-9]{0,2})*[,;:\.\s]*/ ) 
    {
	$mach -> warning ( "An invalid JEL value \"$value\"" );
	return 1; 
    }
    
    my $v = uc $value ;
    my @J = split ( /[,;:\s\.]+/, $v );
    
    if ( not require ReDIF::JELcodes )   {
	if ( not require SD::ReDIF::JELcodes ) {
	    $mach-> warning ( "can't load JELcodes.pm file" );
	}
    }
    my $J;
    foreach $J (@J) {
	if (exists $JELcodes::JEL{$J}) {
	    push @{$self->contents}, $J;
#	    print "GOOD JEL: $J\n";
#	    $mach->warning( "An good JEL code used \"$J\"" );
	} else {
	    $mach->warning( "An invalid JEL code used \"$J\"" );
	} 
    }
    
    return 1;
}
	
    

