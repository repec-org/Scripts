### 
### Package for creation of SD::Structure objects for the XML validation.
###

package SD::XMLStruct;

use SD::Structure;
use Devel::Assert ':DEBUG';

##############################################################################
=pod

SD::SElement objects hold a 'condition' - some kind of rule by which the
element is identified.

The conditions' 'format' depends on the input events format and/or on
the checker routine.

For XML validation we need the following basic types of conditions:

1 - element start tag of a certain type
2 - end tag (of a certain type)
3 - character data 
4 - PI for a certain target 

The 1 to 4 cases will have simple one-string representations: 
1 - 'element<$ELEMENTTYPE'
2 - 'endtag<$ELEMENTTYPE'
3 - 'cdata'
4 - 'PI<$PITARGET'

please see SD::Input and input-test for more...

For full validation of data we will need further conditions


=cut

1;
##############################################################################

sub new_element_SE {
    my $el_name = shift;

    if ( $el_name eq '#PCDATA' ) {
	return SD::SElement -> new (
				  condition => 'cdata',
				  consume => 1, 
				  method => 'cdata'
				  );
    }

    my $element = SD::SElement -> new 
	(
	 type => 'open',
	 struct_name => $el_name,
	 consume => 1,
	 condition => ['element', $el_name],
	 method => 'element',
	 );
    
    return $element;
}

#############################################################################


use SD::GraphUtil;

build_error_element_structure ();


########################################################################

sub build_error_element_structure {

    my $structure = SD::Structure -> new 
	( 
	  name => '*error*',
	  doctype_class => 'SD::Doc',
	  );

    $structure -> start_elem (
			       SD::SElement -> new (
						    consume => 0,
						    method => 'open',
						    )
				);
    $structure -> finish_elem (
			       SD::SElement -> new (
						    type => 'close',
						    consume => 0,
						    condition => "endtag",
						    method => "close",
						  )
				 );

###  ANY (anonymous container) structure  #####################################

    my $any = SD::Structure->new ( 
				   name => '*container*',
				   doctype_class => 'SD::Doc',
				   );

    $any -> start_elem (
		      SD::SElement -> new (
					   method => 'open',
					   )
			);

    my $container_pool = [ 
			 SD::SElement -> new(
					     condition => "element",
					     type => 'open',
					     struct => $any,
					     struct_name => '*container*',
					     consume => 1,
					     method => 'element',
					 ), 

			 SD::SElement ->new(
					    type => 'close',
					    consume => 1,
					    condition => "endtag",
					    method => 'close',
					 ), 

			 SD::SElement -> new(
					    condition => "cdata",
					    type => undef,
					    struct => undef,
					    struct_name => undef,
					    consume => 1,
					    method => 'cdata',
					    )
			   ];


    my $error_pool = [ 
			 SD::SElement->new(
					 type => 'open',
					 struct => $any,
					 struct_name => '*container*',
					 consume => 1,
					 condition => "element",
					 method => 'element', 
					 ), 

#			 SD::SElement->new(
#					 type => 'close',
#					 consume => 0,
#					 condition => "end",
#					 method => 'close',
#					 ), 

#			 SD::SElement->new(
#					 consume => 1,
#					 condition => "cdata",
#					 method => 'cdata', 
#					 ),
			   ];

    my $pool = $container_pool;
    
    my $error = SD::SElement->new(
				  method => 'default', 
				  );

    $structure -> error_elem ( $error );
    $any -> error_elem ( $error );

    $structure -> pool ( $error_pool ); 
    $any -> pool ( $container_pool );				    

    $SD::XMLStruct::ERROR = $structure;
}



sub build_element_structure {
###    my %par = @_;

    my $s_name = shift;   assert( $s_name ) if DEBUG;
    my $el_name = shift;   

    if( not $el_name ) { $el_name = $s_name ; }
    
    my $structure = SD::Structure -> new ( 
					   name => $s_name,
					   doctype_class => 'SD::Doc',
					   strict_closing => 1,
			);

    $structure -> starter ( "element<$el_name" );

###    $structure -> start_elem ( SD::SElement -> new ( );
    
    $structure -> finish_elem (
			     SD::SElement->new(
					       type => 'close',
					       consume => 1,
					       condition => "endtag<$el_name",
					       )
			       );
    $structure -> error_elem ( SD::SElement-> new ( 
						    type => 'open', 
						    struct => $ERROR,
						    consume => 0, 
						    ) );
    return $structure;

}


sub bind_names_to_elements {
    my $structure = shift;
    my $graph = $structure -> graph();
    my $pool = $structure ->  pool ();

    my $node_no ; 
    my $element ;

    if ( $graph ) { 
    
	$node_no = 1 ;
	while ( $node_no < $graph -> final ) {
	    
	    ( $element ) = $graph -> get_item ( $node_no );	    

	    my $name;
	    if ( not $element -> isa ( 'SD::Element' ) ) {
		$name = $element;
		my $item = $graph -> get_item_ref ( $node_no ) ;
		$element = new_element_SE( $name );
		@$item = ( $element );
	    }
	    $node_no ++;
	}

	if ( $node_no eq $graph->final )  {
	    ( $element ) = $graph -> get_item ( $node_no );	    
	    if ($element eq '-1') {
		my $item = $graph -> get_item_ref ( $node_no ) ;
		@$item = ( $structure->finish_elem );
	    }
	}

    } elsif ($pool) {

	$node_no = 0 ;
	while ( $node_no <= $#$pool ) {
	    
	    ( $element ) = $pool->[$node_no];
	    my $name;
	    if ( not ref ($element) ) {
		$name = $element;
		$pool-> [ $node_no ] = new_element_SE( $name );
	    }
	    $node_no ++;
	}
	push @$pool, $structure->finish_elem;
    }
}
                                                                




