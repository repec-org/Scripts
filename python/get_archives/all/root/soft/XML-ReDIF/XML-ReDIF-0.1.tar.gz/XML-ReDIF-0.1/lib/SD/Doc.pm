package SD::Doc;

use Class::Generate qw( &class );

class( 'SD::Doc' =>
       [
	type => "\$",      ### structure name
	contents => "\$", 
	data => "\$",
	errors => "\$",
	],
       -use => [ "Devel::Assert qw(:DEBUG)" ],
       -options => { allow_redefine => 1 }, 
       ) ;

sub pd {
    print @_ if $SD::Doc::DEBUG;
}

sub open { 
    my $self = shift;
    my $mach = shift;
    my $input = shift;
    
    my $type = $mach -> name ;

    if ( defined ($input) and $input->type() eq 'element' ) {
	$type = $input -> data();
    }

    pd "- SD::Doc::open" , "  :",  $type, "\n";
  
    my $contents = [ "<" . $type . ">" ];

    if ( defined ($input) and $input->type() eq 'element' ) {
	push @$contents, $input->data2;
    }

    $self->type( $type );
    $self->contents ( $contents );
    $self->errors ( [] );

###    $mach -> doc ( $self->contents );
}


sub error {
    my $self = shift;
    my $mach = shift;
    my $input = shift;

    pd "- SD::Doc::error" , "  :",  $input, "\n";
    if (ref ($input) and $input -> UNIVERSAL::isa ( 'SD::Doc' ) ) {
	$input = $input->contents;
    }
    push @{$self->errors}, $input;
    push @{$self->contents}, { 'error' => $input };
}


sub close { 
    my $self = shift;
    my $mach = shift;
    
    pd "- SD::Doc::close  :" , $self->type, "\n";

#     my $cont = $self->contents ;
#     push @$cont , '-closed-';
}


sub element { 
    my $self = shift;
    my $mach = shift;
    my $element = shift;
    
    pd "- SD::Doc::element : " , $element->type, "\n";

    my $cont = $self->contents ;
    
    push @$cont, $element->contents;
}


sub cdata { 
    my $self = shift;
    my $mach = shift;
    
    pd "- SD::Doc::cdata" , "  :" , $mach -> event , "\n";
    
    my $cont = $self->contents ;
    push @$cont, $mach->event->data;
}


sub cdata_strip { 
    my $self = shift;
    my $mach = shift;
    
    pd "- SD::Doc::cdata" , "  :" , $mach -> event , "\n";
    
    my $cont = $self->contents ;
    my $text = $mach->event->data;
    $text =~ s/^\s+|\s+$//g;
    push @$cont, $text;
}


sub default { 
    my $self = shift;
    my $mach = shift;
    
    pd "- SD::Doc::default\n";
    
    pd "- input: ", $mach->event, "\n";
    
}

sub special {

    my $self = shift;
    my $mach = shift;
#    my $input = shift;
    
    pd "- SD::Doc::special\n";
    
#    pd "- input: $input / " , $mach->event, "\n";

}


sub success {

    my $self = shift;
    my $mach = shift;
    
    pd "- SD::Doc::success\n";
    
}


sub message {

    my $self = shift;
    my $mach = shift;
    
    pd "- SD::Doc::message\n";
    
    return 0;
}







