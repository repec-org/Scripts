#!/usr/bin/perl

use SD::Machine;

use Class::Generate '&class' ;

class ( 'SD::SuperM' => 
   [
    
    checker => "\$",   ### checker code reference
    struct  => "\$",   ### root structure reference
   
    mach    => "\$",   ### current machine SD::Machine object
    
###    state   => "\$",   ### 
    
    stack   => "\$",   ### previous machines stack
    result  => "\$",   ### final outcome of the machine-machine

###    error   => "\$",

    new => { 
	post => q| 

	    $mach = SD::Machine -> new;
	assert ( $struct -> UNIVERSAL::isa ( 'SD::Structure' ) );
    	$mach -> initialize ( $struct ) ;
    	$mach -> prepare ( undef ) ;
	assert( $checker );
	$mach -> checker ( $checker );
	$stack = [];
        | 
     },
], 

       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);

package SD::SuperM ;

sub input {
    my $self = shift;
    my $input = shift;

  INPUT: while (1) {
      my $result = $self -> mach -> input ( $input );
      if (ref $result eq 'ARRAY')  {
	  if ( $result->[0] eq 'open' ) {
	      
	      my $s = $result ->[1];
	      assert ( $s -> UNIVERSAL::isa ( 'SD::Structure' ) );
	      
	      my $mach = SD::Machine -> new   ### opening new SD::Machine
		  ( super_doc => $self->mach->doc ) ;  
	      $mach -> initialize ( $s ) ;
	      $mach -> prepare ( $input ); ###
	      $mach -> checker ( $self->checker );
	      
	      push @{$self->stack},  $self->mach ;
	      $self -> mach ( $mach );
	      
	  } elsif ( ( $result -> [0] == 1 ) 
		    or ($result->[0] == 0 )  ) {
	      my $mach = $self->mach;
	      if ( scalar @{$self->stack} ) { 
		  $self->mach ( pop @{$self->stack} ) ;
		  $self->mach -> sub_result ( $result->[1], $result->[0] );
		  $self->mach -> collect_user_messages( $mach );
	      } else {
		  $self->result ( $result );
		  return $result;
	      }

	  } elsif ( $result->[0] eq 'goto' ) {
	      die "not implemented 'goto' action";
	  }
	  if ( $result -> [2] ) { ### input consumed? 
	      last INPUT;
	  }
	  
      } else {
	  if ( $result ) {
	      last INPUT;
	  }
      }
      
      print "INPUT hasn't been CONSUMED!";
  }
    $self->result (1);
    return 1;
}



1;






