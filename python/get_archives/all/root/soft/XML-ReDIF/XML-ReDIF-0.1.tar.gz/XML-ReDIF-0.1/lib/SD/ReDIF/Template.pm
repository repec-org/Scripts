package SD::ReDIF::Template;

@ISA = ( 'SD::Doc' );


sub open {
    my $self = shift;
    my $mach = shift;
    $self->data ( { type => $mach->event->data } );
    $self->SUPER::open($mach);
    my $h = $mach->event->data2->{handle};
    if (not defined $h) {
	$mach -> error ('No handle attribute in the template start tag' ) ;
	return 0;
    }
    if ($h !~ /^(?i)[\w\d\_\:]+$/ ) {
	$mach -> error ( 'Wrong handle format in the template start tag' );
    }
    $self->data-> {handle} = $h;
}



sub close {
    my $self = shift;
    my $mach = shift;
    my $input = shift;
    my $success = shift;

    my $t = $self->data->{type};
    my $h = $self->data->{handle} ;

    print " - template " , $h ? "'$h' " :'' , 
          "(type '$t'): " , $success ? "OK" : "invalid", 
    "\n";
}




