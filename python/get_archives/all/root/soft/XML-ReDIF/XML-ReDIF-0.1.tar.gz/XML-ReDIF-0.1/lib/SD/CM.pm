
package SD::CM;

### 
###  The content model parsing and graph-building module. 
###  

=pod

=head1 NAME

SD::CM - the content model parsing and graph-building module.

=head1 SYNOPSYS

  use SD::CM;

  ($graph_model, $occur) = SD::CM::build_graph_model( $content_model );

=head1 DESCRIPTION

The XML 1.0 specification contains the DTD language definition.  Some
elements of this DTD language allow XML users to define the element
types and to restrict the types' valid content.  This is done by
giving the content specification in the element type declaration
(<!ELEMENT ...). 

According to the XML 1.0, the content specification may be of type:
EMPTY, ANY, mixed or element content.  Element content is to constrain
the possible (valid) content to some combination of (other?) element
types.  This is expressed in XML by a content model: 'a simple
grammar, governing the allowed types of the child elements and the
order in which they are allowed to appear.' [XML 1.0, section 3.2.1
Element Content].

A content model specification may look like this (several examples): 

  (head, (p | list | note)*, div?)*
  (front, body, back?)
  (ChapterTitle, ChapterBody)+ 

This module is capable of parsing such content model specifications
and to produce graph-model complex array structures, such as:

  ( ['seq', 'head','', ['alt', 'p', 'list', 'note'],'*', 'div','?'], '*')

which correspons to the first example specification above.  Such array
structures can be easily used to build graphs for the validation
machine structures SD::Structure.

=head2 FUNCTION(S)

=over 4  

=cut
    
    
use Class::Generate '&class' ;


sub get_next_model_token {
    my $model_line = shift;
    $$model_line =~ s/^\s+//;
    $$model_line =~ s/^([(),|+?*]|[^(),|+?*]+)// ;
    return $1;
}


=item * build_graph_model EXPRESSION

The EXPRESSION is expected to contain a content model specification
and is parsed to produce a graph-model as a result.  The graph-model
array reference and the main occur quantifier element (* or + or ?
character) are returned by the function in case of success.  In case
of an error, ( undef, $error_message ) are returned.

=cut

sub build_graph_model {

    my $model_line = shift;

    my $model_line_save = $model_line;
    my ( $model, $occur );

    my $machine; $machine = build_new_model_machine ();

    my $error;    
    my $token; my $last_token;

    my $c = 0;
    while ( 1 ){
        $token = get_next_model_token ( \$model_line );

	$model = $machine -> input ( $token );

	if ( not defined $model ) { $error = 1; last; }
	last if (ref $model ) ;
	last if (not $model_line) ;
	$c++;
	$last_token = $token;
    }
    if (ref $model) {
	$last_token = $token;
	$token = get_next_model_token ( \$model_line );
	
	if (defined $token ) {
	    if( $token =~ /[?+*]/) {
		$occur = $token;
	    } else {
		$error = 1;
	    }
	}

    } else {
	if( not $model_line and not ref $model ) {
##	    $token = "*end*";
	    $error = 1;
	}
    }
    if ($error) {
	$error = sprintf "%s%s%s%s%s%s",
	  "Error while parsing the model line :\n" ,
	  "> $model_line_save\nat token ($c)" ,
	  " '$token' ", ($last_token)? "after '$last_token' " : '', 
	  ($model_line) 
	    ? "(still to parse: '$model_line')" 
		: 'at the end' ,
		"\n";
	return undef, $error;
    }
    return ( $model, $occur );
}


#########################  SD:: MODEL  MACHINE   #############################
#
#


class ( 'SD::ModelMachine' => 
   [
    model  => { type => "\@", post => q| $_model = \@model ;| },
    _model => "\$",  ### a reference to the model array
    
    type   => { 
	type => "\$",
    },
    open   => "\$",

    last => "\$",
    names  => "\$",

###    dstack => "\@",   ### data stack ???

    prev => "\$",
    lower  => "\$",   ### another machine
    
    error => "\$",

    new => { post => q| @model = (1) ; $names = 0; | },
], 

       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);

sub SD::ModelMachine::input {
    my $self = shift;

    if ($self->lower) {
	my $ret = $self->lower() -> input ( @_ );
	if (defined $ret) {
	    return 0;
	} else {
	    return undef;
	}
    }

    my $ret;

    my $inp = shift; 

    my $last ;

    if      ( $inp eq '(' ) {
	$ret = $self-> left_bracket;

    } elsif ( $inp eq ')' ) {
	$ret = $self-> right_bracket;

    } elsif ( $inp eq ',' ) {
	$ret = $self-> comma;

    } elsif ( $inp eq '|' ) {
	$ret = $self-> bar;

    } elsif ( $inp =~ /^[?+*]$/ ) {

	$ret = $self-> occur ( $inp );
	$last = 'occur';

    } elsif ( $inp =~ /^[\w_\-]+$/ ) {

	$ret = $self-> name ( $inp );
	$last = 'name';
    } else {
	return undef;
    }

###    $self->add_dstack ( $inp ) ;
    if ( not defined $last ) {
	$last = $inp;
    }
    $self->last ( $last );
    return $ret;
}

sub SD::ModelMachine::left_bracket {
    my $self = shift;

    my $last = $self->last; 

    if( defined $last ) {
	###  error if after [)?*+] or if not after [,|(]
	if ( $last !~ /^[\,\|\(]/ ) {
	    $self->error(1);
	    return undef;
        }
    } 
    if ($self->open) {
	$self->lower( 
		    SD::ModelMachine->new ( open => 1, prev => $self ) 
		      );
    } else {
	$self->open( 1 );
    }
    return 1;
}


sub SD::ModelMachine::right_bracket {
    my $self = shift;

    my $last  = $self->last; 

    if( defined $last ) {

	if ( $last =~ /^\,$/ ) {
	    $self->error(1);
	    return undef;
	}

	if ( $last eq 'name' and 
	     (not defined ( $self->type )
	      or 
	      $self->type() ne 'alt' ) ){ 
	    $self->add_model ( '' );
        } 
    }

    if ( not $self->names ) {
	$self->model( 0, 'seq' );
    } else {
	if (not defined $self->type) {
	    $self->type('seq');
	}
	$self->model( 0, $self->type );
    }
    
    if ($self->prev) {
	my $prev = $self->prev();
        $prev->add_model( $self->_model );
	$prev->names( $prev->names + 1 );
	$prev->last( 'name' );
	$prev->lower( undef );
    }

    $DB::single = 1;

    return $self->_model ;  
} 


sub SD::ModelMachine::comma {
    my $self = shift;

    my $last  = $self->last; 

    if( defined $last ) {
	
	if ( $last eq 'name' ) {
	    $self->add_model ( '' );
	} 
	if ($last eq 'occur' or $last eq 'name') {
	    my $type = $self->type;
	    if (not defined $type) {
		$self->type('seq');
	    } elsif( $type eq 'alt') {
		$self->error(1);
		return undef;
	    }
	    return 1;
	} else {
	    $self->error(1);
	    return undef;
	}
    } else {
	$self->error(1);
	return undef;
    }
}



sub SD::ModelMachine::bar {
    my $self = shift;

    my $last  = $self->last; 

    if( defined $last ) {
	if ($last eq 'name') {
	    my $type = $self->type;
	    if (not defined $type) {
		$self->type('alt');
	    } elsif( $type eq 'seq') {
		$self->error(1);
		return undef;
	    }
	    return 1;
	}
    } 
    $self->error(1);
    return undef;
}


sub SD::ModelMachine::occur {
    my $self = shift;
    my $occur = shift;

    my $last  = $self->last; 

    if( defined $last ) {
	if ( $last eq 'name' and
	     ($self->type ne 'alt') ) {
	    
	    $self->add_model ( $occur );
	    return 1;
	} 
    } 
    $self->error(1);
    return undef;
}


sub SD::ModelMachine::name {
    my $self = shift;
    my $name = shift;

    my $last  = $self->last; 

    if( defined $last ) {
	if ( $last =~ /^[,|]/ ) {
	    $self->names ( $self->names() +1 );
	    $self->add_model ( $name );
	    return 1;
	} 
    } 
    if ( $self->open ) {
	$self->names ( $self->names() +1 );
	$self->add_model( $name );
	return 1;
    } 
    $self->error(1);
    return undef;
}



#
#  end of:
#########################  SD:: MODEL  MACHINE   #############################


sub build_new_model_machine {
  return  SD::ModelMachine -> new ();
}

1;

=pod 

=back

=head1 BUGS

The parser implemented here is a little bit forgiving.  Thus it is not
fully complient with the XML 1.0 specification.  According to the
specification, no spaces are allowed between a cp (content particle)
and an optional occur quantifier (*|+|?), but this parser just ignores
all spaces.

=head1 SEE ALSO 

Please consult the SD::Graph, SD::GraphUtil and SD::Structure
documentation for the related information.

=cut










