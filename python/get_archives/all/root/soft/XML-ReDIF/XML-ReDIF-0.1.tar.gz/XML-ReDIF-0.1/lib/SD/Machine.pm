##############################################################################
# ###### #   S D : : M A C H I N E   C L A S S 
##############################################################################
#
#  THIS PERL MODULE CONTAINS THE SD::Machine CLASS FOR THE STRUCTURED 
#  DOCUMENT VALIDATION PURPOSES.  IT IS TO BE USED IN CONJUNCTION WITH
#  THE SD::Structure CLASS.  
#
###   SD/Machine.pm file by Ivan Kurmanov for the ReDIF/Zhuleb/SD project
###
###   Created: Dec 1999 
###   Continued: 2000
###
###   $Author$
###   $Date$
###   $Id$
###   $Revision$
###   $Source$
###
###   $Log$



#######   ####         ####     ####    ##
   #     #    #        #   #   #    #
   #     #    #        #    #  #    #     
   #      ####         #####    ####    ##

### TO DO list
# 
#  done   special preset ignore conditions for the input
#         (pre-choice and post-choice)
#         or do that at the SuperM level ...
#
#  done   Flexibility of error messages and non-error message delivery.
# partial Might be devided into two-related to-do items actually
#
#   -     'goto'-that-structure reaction
#
#   -     ANY structure machine implementation, based on pool reaction 
#         selection
#
#   -     Multi-layer pool structure, generalizing error-treatment 
#         and ignore-conditions    
# 

use Class::Generate qw( &class );

class( SD::Machine =>
       [
	struct  => "\$",   ### Doc SD::Structure object reference

	name => "\$",      ### Structure name 
	doctype_class  =>  "\$",   ### Class name of the target data object

	starter => "\$",     ### Same as in SD::Structure
	start_elem => "\$",  ### Same as in SD::Structure

	finisher => "\$",    ### Same as in SD::Structure
	finish_elem => "\$", ### Same as in SD::Structure

	type => "\$",      ### graph | pool | empty | any (from SD::Structure)

	graph    =>        ### if it is graph-based 
	{ type => "\$", post => q| | },

	pool     =>   ### if it is set-based 
 	{ type => "\$", post => q| $self->pool_cd ( [] ); | },

	empty    => "\$", 
	any      => "\$",  ### points to a container object? not yet

	event    => "\$",  ### input event instance var
	checker  => "\$",  ### code reference for comparing 
	                   ### incoming events with the conditions

	consumed => "\$",  ### has the input been properly processed?
		 
	super_doc => "\$", ### higher-level document object
	doc      => "\$",  ### document object
	
	pool_cd  => "\$",  ### pool current data
	position => "\$",  ### graph's current position info 

	error_proc_flag => "\$", ### flag var for error-structure usage 
	                         ### occasions

	element_last_input => "\$",  ### the element to be used on return from
	                             ### a sub-structure machine
###	errors   => "\@",

	umsg_count =>  ### hash reference
             { type => "\$", default => '{error => 0, warning => 0, }' },
	user_messages => "\@", 

	'&is_valid'   => ### has the structure any errors?
	   '  return 0 if $self->umsg_count->{error};
              return 1; ',
    
	result => "\$",
	], 

       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);


package SD::Machine;

use Devel::Assert ':DEBUG';

=pod 

=head1 NAME

SD::Machine - configurable Finite State Automata, recognizing a
document structure in accord with a SD::Structure object

=head1 SYNOPSYS

    use SD::Machine; 
    $machine = SD::Machine -> new ();
    ...
    $machine -> input ( $EVENT );

=head1 DESCRIPTION

The machine is run by its input through the input() method.  The
machine reacts to input by creating a 'target document object' and
through the returned values.  The machine knows nothing about the
input.  But a Structure object knows. 

A machine works according to the rules, encoded in a SD::Structure
object.

A typical rule would require the machine's master to open another
(level of) the document structure (which corresponds to using, most
likely, another SD::Structure object and creating another
SD::Machine object).

The machine's master is something that invokes the input() method on a
SD::Machine object.

Another typical rule would require the machine's master to close this
machine.

Another typical rule would trigger an error when some unknown element
appears in the input or when an element appeared is not correctly
placed within the structure.

In general the machine's confiuration includes: allowed input scope
and reaction to different kinds of input, target document building
information, error-treatment instructions, structure completition/
machine closure information.

=head2 METHODS

=over 4

=item * new ( [param1 => value1 [, ...]] ) ;

=item * input ( INPUT_EVENT );

    input returns: 1 on a normal, consumed input
    [ 'open', $structure, $consume_flag ] for a new structure/machine opening 
    [ 1, $object, cosumed_flag ]  on a succesful machine finish
    [ 0, $object, consumed_flag ] on a machine finish with errors
    
=item * is_valid 

This methods checks if during the parse any errors has happened. True if own 
umsg_count->{error} is positive.

=back    
    
=cut

use strict;
use SD::MachTypes;

sub pd ;

sub pd {
    print @_ if $SD::Machine::DEBUG;
}

##############################################################################
# sub   I N I T I A L I Z E
##############################################################################

sub initialize {
    my $self = shift;
    my $struct = shift;
    my $continue_flag = shift || 0;
    
    $self-> struct ( $struct );

    $self-> type ( $struct -> type ) ;
    $self-> name ( $struct -> name ) ;
    $self-> doctype_class  ( $struct -> doctype_class );
 
    $self-> starter     ( $struct -> starter ) ;
    $self-> start_elem  ( $struct -> start_elem ) ;
    $self-> finisher    ( $struct -> finisher ) ;
    $self-> finish_elem ( $struct -> finish_elem ) ;

    $self-> type ( $struct -> type ) ;
    $self-> consumed ( 0 );

    my $type = $self->type;
    {
	no strict 'refs';
	$self-> $type ( $struct -> $type () ) ;

    }				

    if ($self->start_elem) {
	$self-> position ( undef );
    } else {
	$self-> position ( 0 );
    }
}

##############################################################################
# S U B   P R E P A R E 
##############################################################################

sub prepare {
    my $self = shift;
    my $input = shift; 

    assert ( not defined $self->event ) if DEBUG;

    my $str = $self->struct;

    $self -> event( $input );

    $self -> doc ( $self->doctype_class -> new() );  #### ??! 
    $self -> doc -> open ( $self, $input ); ## ?!

    if ( not defined $self->position ) {
###	if ( defined $self->start_elem ) {
###	    $self-> element_execute ( $self->start_elem ) ;
###	} else {
###	    my $class      = $self->doctype_class;
###	    my $method_new = $self->doctype_methods( 'new' );
###    
###	    unless (not defined $class) {
###		$self->doc( $class -> $method_new ( $input ) );
###	    } 
###	}
	$self->position ( 0 );
    }
###    print "\n";


}


##############################################################################
# S U B   I N P U T 
##############################################################################

sub input {
    my $self = shift;
    my $input = shift; 

    pd "\n  + INPUT: ", $input->describe, ": ";

    $self -> consumed ( 0 );
    $self -> event( $input );
    
    ### Check if the input event shall be ignored
    ### before even considering 
    my $ignore = $self->struct->ignore_pre ;
    if ( defined $ignore ) {
	my $checker = $self->checker;
	foreach ( @$ignore ) {
	    if ( &$checker ( $_, $input ) ) {
		### Yes, need to ignore! 
		pd "IGNORED (pre)";
		return 1;
	    }
	}
    }

    pd "\n";

    pd "i * NAME: ", $self->name, "\tTYPE: " , $self->type, "\n" ;
    
    my $pr = $self -> type . '_proc';
    my $item = $self -> $pr ();
    my $return;
    
    if ( ref ( $item ) eq 'ARRAY' ) {
	
	if ( $self->check_finish ) {
	    ### FORCED FINISH
	    $self->error( "Incomplete structure is closed" );

	    $self->consume();  # ?
	    $return = [ 0, $self->doc, $self->consumed ];

	} else {
	    
	    ### Check if the input event shall be ignored
	    ### without causing an error 

	    my $ignore = $self->struct->ignore_post ;
	    if ( defined $ignore ) {
		my $checker = $self->checker;
		foreach ( @$ignore ) {
		    if ( &$checker ( $_, $input ) ) {
			### Yes, need to ignore! 
			pd "IGNORED (post)";
			return 1;
		    }
		}
	    }

	    if( not @$item ) {
		$self-> error ( "Wrong content for the <", $self->name, 
				"> structure" );
	    }
#	    $return = [ 0, $self->object, $self->consumed ];
	    return ( $self-> input_error );

	}
    }
    elsif ( ref ( $item ) 
	    and $item -> UNIVERSAL::isa ( 'SD::SElement' ) ) {

	pd "ACTION: [" , $item -> condition,  " / ";
	if (defined $item->type) {
	    pd   $item->type, " / ", 
	    ( defined $item -> struct_name ) ? $item ->struct_name : ''	," / ";
	}
	pd $item->consume ? "consume" : "non-consume"; 
	if ( $item-> method ) { pd " / m: ", $item->method ; } 
	pd "]\n";
	
	$return = $self-> element_refer ( $item ) ;
	if (not $item->type) {
	    $self-> element_execute ( $item );
	}

    } else {
	die;
	$return = $self-> consumed;
    }

    $self->result ( $return );
    return $return;
}


##### I N P U T   E R R O R  ##################################################

sub input_error {
    my $self = shift;

    my $ret = 1;

###  Decisions to take at this point: 
###   1- include the input into the doc and how if yes?
###   2- open a special error-structure ?

### answer 1: yes, use method error on $self->doc
### answer 2: yes, if the structure's error structure asks for that

    my $local;

    $local = 1 if not defined $self->struct->error_elem 
	or not defined $self->struct->error_elem->struct;

    if (not $local) {
	my $res = $self->error_proc ;
	
	if ( ref( $res ) ne 'ARRAY' ) {
	    $ret = $self -> element_refer ( $res ) ;

	    if ( $ret->[0] eq 'open' ) {
		$self->error_proc_flag ( 1 );
	    }
	} else {
	    $local =1 ;
	}
    }
    if ( $local ) {
	$self->doc->error ( $self, $self->event );  ### ?!
    }
    return $ret; 
}

##############################################################################
#  SUB  ERROR_PROC  # 
##############################################################################

sub error_proc {
    my $self = shift;
    my $event = $self->event;

    my $error_elem =  $self->struct->error_elem;
    my $error_str = $error_elem->struct;

    assert( $error_str->type eq 'pool' );

    my $pool = $error_str->pool;

    my $elems = $pool;
    my $ind = 0;

    pd "... error alternatives: [";
    my $c=0;
    foreach ( @$elems ) {
	if ($c) { pd " | "; }
#	pd $elems->[$c++]->condition;
    }
    pd "]\n";

    my @way = $self -> check_actions ( $elems );

    if ( $#way == 0 ) {
	my $way = $way[0];
	return $elems->[$way];
    } elsif ( $#way < 0 )  {
	return [];
    } elsif ( $#way > 0 )  {
	die "ERROR AMBIGUITY: ", join ( ' ', @way ), "\n";
    }

}



##### C O N S U M E ###########################################################
sub consume {
    my $self = shift;
        
###    pd " %%%%%%%% CONSUME %%%%%%%%%% ";
    $self->consumed( 1 );
###    $self->add_content ( $self->event );
}




##############################################################################
# SUB   E L E M E N T _ E X E C U T E
##############################################################################

sub element_execute {
    my $self = shift;

    my $element = shift;  assert ( $element );

    $self->consume;

    my @args = @_;

    my $method = $element->method ;
    return if not defined $method;

    $self->doc -> $method ( $self, @args );
}

###############################################################################
##  ELEMENT REFER        ######################################################
###############################################################################

sub element_refer {
    my $self = shift;
    my $element = shift;  assert ( $element );

    my $type = $element -> type ;

    if ( $element->consume ) {
	$self->consume();
    }

    if ( not defined $type ) {
	return 1;
    }

    if ( $type eq 'open' ) {

	$self-> element_last_input ( $element );
	return [ 'open', $element-> struct (), $self->consumed ];

    } elsif ( $type eq 'close' ) {

###	$self->element_execute ( $element );

###	my $t = $self->type . '_close_check';
###	$self -> $t ;  ### run type-specific method ?!

#	if ( not $self->is_valid or not $self->struct->strict_closing ) {
#	    $self -> doc -> close ( $self, $self->event ); ## ?!
#	}
	if ( $self->is_valid ) {
	    $self -> doc -> success ( $self, $self->event ); 
        } 
        $self -> doc -> close ( $self, $self->event, $self->is_valid ); ## ?!
        $self->consumed ( $element->consume ) ;

	return [ ( $self->is_valid () ? 1 : 0 ), $self->doc,
		 $self->consumed ];
	
    } elsif ( $type eq 'goto' ) {
	
	return [ 'goto', $element -> struct(), $self->consumed ];
    } else { 
	return 1; 
    }
}




##############################################################################
# S U B   S U B _ R E S U L T 
##############################################################################

sub sub_result {
    my $self = shift;
    my $result = shift;
    my $valid = shift;

    if ( $self->error_proc_flag ) {
	$self->doc->error ( $self, $result );
	$self->error_proc_flag ( 0 );
	return;
    }

    my $element = $self->element_last_input ;
    assert ( $element );
    
    $self->element_execute( $element, $result, $valid );
}


##############################################################################
# ####### #  SD :: USERMESSAGE  CLASS  DEFINITION
##############################################################################

use Class::Generate qw( &class );

class ( 'SD::UserMessage' => 
	[
	 text =>     ### the (error) message
	 { type => "\$", required => 1 },

	 input =>    ### input event that has caused the error
	 { type => "\$", required => 1 },

	 level =>    ### error seriousness level
	 { type => "\$", required => 1 },

	 context =>  ### the source-file context of an error
	 { type => "\$", required => 0 },

	 source =>   ### the source data piece, that has caused the error
	 { type => "\$", required => 0 },

	 prefix => "\$",

	 '&describe' => q|
	 return join '', "! \u$level ", "($prefix): ", "$text at:\n" , 
	 $context ; 
	 |,

	],
#    -use => [ "Devel::Assert ':DEBUG'" ],
#    -options => {  allow_redefine => 1 },
);

###
# SUB   SEND USER MESSAGE    ( MSGTEXT, MSGTYPE )
###############################################################################
sub send_user_message {   ### a hash of the above structure
    my $self = shift;
    my $text = shift;   assert( $text ) if DEBUG;
    my $level = shift;  assert( $level ) if DEBUG;

    my $event = $self->event;
    my $parser = $self->event->parser;

    my $prefix = "Line " . $parser-> current_line . 
                 ", Col ". $parser-> current_column .
		 ", BP ". $parser-> current_byte ;    

    my %msg = ( text => $text,
	     level => $level,
	     context => $parser->position_in_context (0),
	     source => $parser->recognized_string (),
	     prefix => $prefix,
		input => $event,
	     );

    my $msg = SD::UserMessage -> new ( %msg );

    if (not $self->doc->message ( $msg ) ) {
	print $msg -> describe ;
    }
    assert( $msg );

    $self->add_user_messages ( $msg );
    my $counts = $self-> umsg_count;
    $counts -> {$msg->level} ++;

}

# SUB  COLLECT  USER  MESSAGES (  MACHINE_OBJECT  )
###############################################################################
sub collect_user_messages {
    my $self = shift;
    my $mach = shift;  ### another machine
    
    $self->add_user_messages ( $mach->user_messages );

    my $counters = $mach->umsg_count;

    foreach ( keys %$counters ) {
	$self->umsg_count -> {$_} += $counters->{$_};
    } 
}

##############################################################################
# S U B    E R R O R 
##############################################################################

sub error {
    my $self = shift;
    my @msg = @_;
    my $text = join '', @msg;
    $self->send_user_message ( $text, 'error' );
}

##############################################################################
# S U B    W A R N I N G 
##############################################################################

sub warning {
    my $self = shift;
    my @msg = @_;
    my $text = join '', @msg;
    $self->send_user_message ( $text, 'warning' );
}





###################   N A V I G A T I O N    #################################

##############################################################################
# S U B   P R E V I E W _ G R A P H _ D I R E C T I O N S 
##############################################################################


sub preview_graph_directions {
    my $directions = shift;
    my $graph      = shift;

    my ( @conditions, @elements );
    my $ind = 0;

    foreach my $d ( @$directions ) {
	my ( $item ) = $graph -> get_item ( $d );
	( $elements[ $ind++ ] ) = $item ;
	if (ref ( $item ) ) {
	    push @conditions, $item -> condition () ;
	} elsif ( $item eq '-1' )  {
	    die;
	    push @conditions, undef ;
	}
    }
    return ( \@elements, \@conditions );
}


##############################################################################
# S U B  C H E C K _ C O N D I T I O N S 
##############################################################################

sub check_conditions {

    my $self = shift;
    my $conditions = shift;

    my $event = $self-> event;

    my $checker = $self-> checker;  assert ( ref $checker eq 'CODE' );
    my $ind = 0; my @way = () ;

    foreach my $cond ( @$conditions ) {
	if ( & $checker ( $cond, $event ) ) {
	    push @way, $ind;
	}
	$ind ++;
    }

    return @way;

}


##############################################################################
#  S U B   C H E C K _ A C T I O N S 
##############################################################################

sub check_actions {

    my $self = shift;
    my $actions = shift;

    my $event = $self-> event;

    my $checker = $self-> checker;
    my $ind = 0; my @way = () ;

    foreach my $act ( @$actions ) {
	if ( &$checker ( $act->condition, $event ) ) {
	    push @way, $ind;
	}
	$ind ++;
    }
    return @way;
}


##############################################################################
#  S U B   C H E C K _ F I N I S H 
##############################################################################

sub check_finish {

    my $self = shift;

    my $checker = $self-> checker;
    my $finisher = $self-> struct -> finisher;
    my $event = $self-> event;

    return 0 if not defined $finisher;

    if ( &$checker ( $finisher, $event )  ) {

	######  FINISH THE MACHINE' S JOB !
	return 1; 
    }

}

###############################################################################



1;
__END__















