package ReDIF::messages;

#
#  This module is obsolete now ...
#

1;




