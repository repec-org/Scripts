package Processor;

sub start_redif_dir {
    print "start: ", $_[1], "\n";
}

sub end_redif_dir {
    print "end: ", $_[1], "\n";
}

sub redif_file {
    print "file: ", $_[2], "\n";
}

sub warning {
    print "warning: ", $_[1], "\n";
}

sub error {
    print "error: ", $_[1], "\n";
}

package main;

use RePEc::Find;

my $dir = shift;
# my $dir = '/home/ivan/data/RePEc';
my $P = {};
bless $P, 'Processor';

RePEc::Find::traverse_directory( $dir, $P );


