
use Class::Generate qw( &class );

class( 'SD::DocType' =>
       [
	# input params
	name => "\$",         ### Spec name 
	root_element => "\$", ### root elementType
	root_type => "\$",    ### root content Type
	doctype_class =>"\$", ### class name of the target data object

	# vars
	typestable => "\%",
	structure => "\$",

	], 
       
       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);


class( 'SD::SType' =>
       [
	# input params
	name => "\$",         ### SType name 
	
	parent => "\$",   ### upper type's reference

	doctype_class =>"\$", ### class name of the target data object
	ctype => "\$",        ### logical content-type 
	
###	root => "\$",         ### if the type is root,
	
	# sequence
	# choice
	# string (CDATA)
	# MIXED
	# EMPTY
	# ANY
	
	elements => "\$",   ### array reference 
	
	# vars

	stype => "\$",        ### SD::Structure type
	stype_data => "\$",   ### data for the SD::Structure
	                      ### graph - [['seq', ], occur]
	                      ### pool  
	                      ### empty
	                      ### any

	structure => "\$",
	typestable => "\%",

	struct_templates => "\%", ### a library of templates for SD::Structure
	                          ### objects (only at root level?)

	s_template =>   ### the name of a structure template
	{ type => "\$",  default => "default" },

	built => {
	    type => "\$", default => '' },
	
	], 
       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);


package SD::SType;



sub make_default_structure {
    my $self = shift;

    my $el_name = shift;

    my $empty_cdata = ['cdata', ['RE', '\s+'] ];
    my $structure = SD::Structure -> new 
               ( 
#   name => $s_name,
		 doctype_class => 'SD::Doc',
		 strict_closing => 1,
			);

    $structure -> starter ( ['element', $el_name ] );

    $structure -> finish_elem (
			     SD::SElement->new(
					       type => 'close',
					       consume => 1,
					       condition => 
					       ["endtag",$el_name],
					       )
			       );
    $structure -> error_elem ( SD::SElement-> new ( 
						    type => 'open', 
						    struct => 
						    $XMLStruct::ERROR,
						    consume => 0, 
						    ) );

}


sub make_doc_type {
    my $class = shift;
    my $root = shift;
    
    my $self = $class->make_pool_type ( 'DOCTYPE' );

    $self-> add_pool_element ( $root, $root, [1, 1] );


    $self-> add_pool_element ( "XMLDecl>",'', [0, 1] );

    $self-> add_pool_element ( "DTD>",'', [0, 1] );

    $self-> add_pool_element ( "COMMENT>",'', [undef, undef] );


    my $str =  $self -> produce_structure_object ( 'DOCTYPE' );

    $str -> finish_elem () -> condition ( 'EOF' );
    $str -> finisher ( 'EOF' );
    
    $self-> structure ( $str );
}



sub new_type {
    my $self = shift;
    
    my $name = shift; assert( $name );
    my $ctype = shift; assert( $ctype );

    my $type = SD::SType -> new(
				name => $name,
				ctype => $ctype,
				parent => $self,
				);

    assert ( not defined $self->typestable( $name ) ) if DEBUG;
    $self->typestable ( $name, $type );

    return $type;
}



sub make_sequence_type {
    my $self = shift;
    
    my $name = shift; assert( $name );
    my $type = $self-> new_type ( $name, 'sequence') ;

    $type->elements ( ['seq'] );

    return $self;
}


sub add_sequence_element {
    my $self = shift;     assert( $self    );
    my $element = shift;  assert( $element );
    my $type = shift;     assert( $type );  ### 
    my $occur = shift;    

    my %occurs = ( '*' => 1,
		   '?' => 1,
		   '+' => 1,
		   '1' => 1 );
    
    if (not defined $occur or $occur eq '') {
	$occur = '1';
    } else {
	assert ( $occurs{$occur} ); 
    }

#    die if $self->symtable( $element );
#    $self -> symtable ( $element, $type );
#    my $els = $self->elements();

    if (not ref $element) {
	$element = "$element<$type";
    } else {
	assert( ref $element eq 'ARRAY' );
	assert( $element->[0] eq 'alt' );
    }

    push @$els, $element, $occur;
}


sub produce_element_of_type { 
    my $self = shift;
    my $element = shift;
    my $stype_name = shift;
    my $structure;

    ### first task is to look-up the name in the 
    ### set of types' symbol tables
    
    my $stype = $self->typestable ( $stype_name );   
    my $lookup = $self;
    
    while ( not defined $stype ) {
	$lookup = $lookup-> parent () or next;
	$stype = $lookup -> typestable ( $stype_name ) ;
    }
   
    if( not defined $stype) { return undef; }

    assert( $stype -> name () eq $stype );

    $structure = $stype->produce_structure_object ( $element );
    
    return $structure;
}


sub produce_structure_object { 
    my $self = shift;
    my $element = shift;

    my $str;
    if ($self->stype eq 'sequence' ) {
	$str = $self->produce_sequence_structure_object ( $element ) ;
    }
 
    resolve_names_to_elements ( $str );
    return $str;
}

use SD::Graph;
use SD::GraphUtil;
use SD::XMLStruct;

sub produce_sequence_structure_object { 
    my $self = shift; assert ( $self ) if DEBUG;
    my $element = shift;

    if ( not $self-> built ) {
	
	my $seq = $self->elements;
	my $graph = SD::GraphUtil::model ( $seq );
	$self->stype_data ( $graph );
	$self->built ( 1 ) ;
    } 
    
    my $str = $self-> make_default_structure ( $element );
#### build_element_structure( $element );
    
    $str -> graph ( $self->stype_data );

    return $str;
}

#### transfer here the SD::XMLStruct::build_element_structure
#### and the SD::XMLStruct::bind_names_to_elements ( $str );

sub build_element {
    my $type = shift; 
    my $struct_name = shift;
    my $struct = shift;
    my $consume = shift;
    my $condition = shift;
    my $min = shift;
    my $max = shift;
    my $method = shift;

    return SD::SElement->new(
			     type => $type,
			     consume => $consume,
			     condition => $condition,
			     struct_name => $struct_name, 
			     struct => $struct,
			     min => $min, 
			     max => $max,
			     method => $method,
			     );
};

sub build_open_element { 
    my $name = shift;
    my $stype = shift;
    return build_element ( 'open', $stype, undef, 1, ['element', $name] );
}

#####  from XMLStruct.pm: start ##################### 

sub resolve_names_to_elements {
    my $structure = shift;

    my $graph = $structure -> graph();
    my $pool = $structure ->  pool ();
    my $pool_data = $structure -> pool_data ();

    my $node_no ; 
    my $element ;

    if ( $graph ) { 
    
	$node_no = 1 ;
	while ( $node_no < $graph -> final ) {
	    
	    ( $element ) = $graph -> get_item ( $node_no );	    

	    my $name;
	    if ( not $element -> isa ( 'SD::Element' ) ) {
		$name = $element;
		my $item = $graph -> get_item_ref ( $node_no ) ;
		print "NAME ELEMENT: '$name' \n";
		$element = build_open_element( $name );
		@$item = ( $element );
	    }
	    $node_no ++;
	}

	if ( $node_no eq $graph->final )  {
	    ( $element ) = $graph -> get_item ( $node_no );	    
	    if ($element == -1) {
		my $item = $graph -> get_item_ref ( $node_no ) ;
		@$item = ( $structure->finish_elem );
	    }
	}

    } elsif ($pool) {

	$node_no = 0 ;
	while ( $node_no <= $#$pool ) {
	    
	    ( $element ) = $pool->[$node_no];
	    my $name;
	    if ( not ref ($element) ) {
		$name = $element;
		my $el = new_open_element( $name );
		$pool-> [ $node_no ] = $el;
		my $el_occur = $pool_data->[$node_no];
		if ( defined $el_occur ) {
		    assert ( ref $el_occur eq 'ARRAY' );
		    my ( $min, $max ) = @$el_occur;
		    $el->min ($min) if defined $min ;
		    $el->max ($max) if defined $min ;
		}
	    }
	    $node_no ++;
	}
	push @$pool, $structure->finish_elem;
    }
}
                                                             


#####  from XMLStruct.pm: end ####################### 



sub make_sequence_type {
    my $self = shift; assert( $self );
    my $name = shift; assert( $name );
    my $symtable = shift; 
    
    
}

sub make_sequence_type {
    my $self = shift; assert( $self );
    
    
}


sub make_sequence_type {
    my $self = shift; assert( $self );
    
    
}


sub make_sequence_type {
    my $self = shift; assert( $self );
    
    
}





1;

__END__

=pod

=head1 DESCRIPTION

XML view:

    - expect any PI ?
       - any specific PI target?
          - targets?
       - require it?

    - ignore DTD ?
    - ignore comments ?

