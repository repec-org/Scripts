package ReDIF::Parser::NO_UTF8;

#      $Id: NO_UTF8.pm,v 1.2 2002/07/14 12:12:53 ivan Exp $
$VERSION = do { my @r=(q$Revision: 1.2 $=~/\d+/g); sprintf "%d."."%02d"x$#r,@r }; 

#########################################################################
# SUB  R E M E M B E R    A T T R I B U T E     (INCLUDE_ATTRLINE)
#########################################################################
#

# use ReDIF::Unicode;

sub ReDIF::Parser::Core::get_non_utf8_value {

    use bytes;

    my $va = shift;

    return $va;
}


1;


