package SD::SType::sequence;


use SD::SType;  ### or is that implied? 
use SD::STypeMake;  ### 

use strict;
use vars qw( @ISA  $X );
@ISA = ( 'SD::SType' );

use Devel::Assert ':DEBUG';

use Class::Generate;

sub make_new {
    my $self = shift;
    
    my $name = shift; assert( $name );
    my $basetype = shift;

    my $type = $self -> new_type ( $name, 'sequence' ) ;

    $type->ignore_ws_cdata ( 1 );
    $type->ignore_comments ( 1 );

    if ( $basetype ) {
	$type->inherit_from ( $basetype ) ;
    } else {
	$type -> stype_data ( ['seq'] );
    }

    return $type;
}



sub set_sequence { 
    my $self = shift;
    my $seq  = shift; assert ( $seq ) if DEBUG;
    $self->stype_data ( $seq );
}


sub add_element {
    my $self = shift;     assert( $self    );
    my $element = shift;  assert( $element );
    my $type = shift;   ###  assert( $type );  ### --- 
    my $occur = shift;    

    my %occurs = ( '*' => 1,
		   '?' => 1,
		   '+' => 1,
		   '1' => 1 );
    
    if (not defined $occur or $occur eq '') {
	$occur = '1';
    } else {
	assert ( $occurs{$occur} ); 
    }

    my $els = $self->stype_data;

    if (not ref $element) {
	$element = "$element<$type";
    }

    push @$els, $element, $occur;
}

############  PRODUCE SEQUENCE STRUCTURE OBJECT  #########################

use SD::Graph;
use SD::GraphUtil;

sub produce_structure_object_core  {         ##### SEQUENCE
    my $self = shift; assert ( $self ) if DEBUG;
    my $element = shift;

    my $seq = $self->stype_data;
    assert ( $seq->[0] );   
    my $graph = SD::GraphUtil::model ( $seq );

    my $str = $self-> make_default_structure ( $element );

    $str -> graph ( $graph );

    return $str;
}


##################################  CHOICE  ##################################

package SD::SType::choice;  

use SD::SType;  ### or is that implied? 
use SD::STypeMake;  ### 

use strict;
use vars qw( @ISA  $X );
@ISA = ( 'SD::SType' );

use Devel::Assert ':DEBUG';

use Class::Generate;

sub make_new {
    my $self = shift;
    my $name = shift; assert( $name );
    my $basetype = shift;

    my $type = $self -> new_type ( $name, 'choice' ) ;

    assert ( ref ( $type ) eq 'SD::SType::choice' );

    $type->ignore_ws_cdata ( 1 );
    $type->ignore_comments ( 1 );

    if ( $basetype ) {
	$type->inherit_from ( $basetype ) ;
    } else {
	$type -> elements ( [] );
	$type -> stype_data ( [] );
    }

    return $type;
}



sub set_pool { 
    my $self = shift;
    my $p  = shift; assert ( $p ) if DEBUG;
    $self->elements ( $p );
}

sub set_pool_occur { 
    my $self = shift;
    my $po  = shift; assert ( $po ) if DEBUG;
    $self->stype_data ( $po );
}


sub add_element {
    my $self = shift;     assert( $self    );
    my $element = shift;  assert( $element );
    my $type = shift;     
    my $occur = shift;    ####  [min, max]

    my %occurs = ( '*' => [undef,undef],    ####  [min, max]
		   '?' => [undef, 1],
		   '+' => [1, undef],
		   '1' => [1, 1] );
    
    if (not defined $occur or $occur eq '') {
	$occur = [undef, undef];
    } elsif ( not ref $occur ) {
	$occur = $occurs{$occur}  ;
    }

    my $els = $self->elements;
    my $pd = $self->stype_data;  ### pool_data

    if (not ref $element) {
	$element = "$element<$type";
    }

    push @$els, $element;
    push @$pd, $occur;
}

############  PRODUCE CHOICE STRUCTURE OBJECT  #########################

use SD::Graph;
use SD::GraphUtil;

sub produce_structure_object_core  {         ##### CHOICE
    my $self = shift; assert ( $self ) if DEBUG;
    my $element = shift;

    my $pool = $self->elements;
#    my $pd = $self->stype_data;
#    assert ( $#$pd == $#$pool );  ###  both archives must be of the same size

    my $str = $self-> make_default_structure ( $element );

    my $ind = 0;

#    foreach my $el ( @$pool ) {
#	$el -> min ( $pd->[$ind]->[0]   );
#	$el -> max ( $pd->[$ind++]->[1] );
#	
#    }

    $str -> pool ( $pool );

    return $str;
}







1;









