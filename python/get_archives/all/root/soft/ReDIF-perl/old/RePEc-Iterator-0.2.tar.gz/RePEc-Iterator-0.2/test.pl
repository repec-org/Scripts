#!/usr/local/bin/perl

###   This is a test script for the RePEc::Iterator module.  

###   It does nothing useful but prints out all of the
###   Iterator-generated events with their data.


use Events;

use RePEc::Iterator;

$repec_directory = '/home/ivan/RePEc';
$authority = "RePEc";

Events -> register_event_handler( 'REDIF::*',
				  \& print_event );

Events -> register_event_handler( 'REPEC::ITERATOR::?',
				  \& print_event );

sub print_event {
    my $event = shift;

    $event =~ s/::/ /g;

    print "EVENT: $event  [ ", join ( ', ', @_ ), " ] \n";
    return 1;
}


RePEc::Iterator::main ( $repec_directory, $authority );


__END__
