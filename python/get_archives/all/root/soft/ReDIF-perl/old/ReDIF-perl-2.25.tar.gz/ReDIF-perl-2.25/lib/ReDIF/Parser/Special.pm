package ReDIF::Parser::Special; 

use strict; 
use vars qw( @ERRORS @WARNINGS );
use vars qw( $value $result $evaluation );

sub error {
    my $text = shift;
    push @ERRORS, $text;
}

sub warning {
    my $text = shift;
    push @WARNINGS, $text;
}

1;
