package ReDIF::Unicode;

##  Copyright (c) 1997-2001 Ivan Kurmanov. All rights reserved.
##
##  This code is free software; you can redistribute it and/or modify it
##  under the same terms as Perl itself.

$VERSION = "0.1";


use Exporter;
@ISA = ( 'Exporter' ) ;
@EXPORT_OK = qw( &has_utf8_bom &has_non_latin1_unicode 
		 &latin1_from_utf8   &utf8_from_latin1 );

$BOM_UTF8 = '\xef\xbb\xbf' ;

no utf8;

sub has_utf8_bom {
    my $string = shift;
    
    return $string =~ /^$BOM_UTF8/ ;
}


sub has_non_latin1_unicode {
    use utf8;
    
    my $string = shift;
    
    return $string =~ m/[^\x00-\xFF]/ ;
}


use Unicode::String qw( &utf8  &latin1 );

use Carp;

sub utf8_from_latin1 {
    my $data = shift || confess;
    return latin1( $data ) -> utf8() ;
}

sub latin1_from_utf8 {
    return utf8( shift ) -> latin1() ;
}
