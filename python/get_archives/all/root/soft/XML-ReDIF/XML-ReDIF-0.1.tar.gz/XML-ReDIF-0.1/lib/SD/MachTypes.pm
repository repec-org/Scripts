package SD::Machine;

#### This is the supplement code to the SD::Machine module. 
###
###  It provides machine-type specific behaviour of the SD::Machine.
###
##############################################################################
# ###### #  G R A P H _ P R O C   handler
##############################################################################

use SD::Machine;

sub pd;
# { print @_ if $DEBUG; }

###   sub graph_close_check {}

sub graph_proc {
    my $self = shift;
    my $event = $self->event;
   
    my $graph = $self->graph;

    my $struct = $self-> struct; assert ( $struct );

    my @directions = $graph->alternatives ( $self->position ) ;

    pd "g + " ; 
    pd "POSITION: ", $self->position , " ";
    pd "DIRECTIONS: " , join ( ' ', @directions ), "\n";
    my $ind = 0;

    my ( $actions, $conditions ) = preview_graph_directions( \@directions,
							     $graph );

#    pd "? : alternatives: ", join ( ', ', @$conditions );
    pd "\n";

    my @way = $self -> check_conditions ( $conditions );

    if ( $#way == 0 ) {
	my $way = $way[0];
	my $dir = $directions[$way];
	$self->position ( $dir ) ;

	return $actions->[$way];

    } elsif ( $#way < 0 )  {

	return [];

    } elsif ( $#way > 0 )  {
	die "AMBIGUITY: ", join ( ' ', @way ), "\n";
    }

}

##############################################################################
# ###### #   P O O L _ P R O C   handler
##############################################################################

sub pool_proc {
    my $self = shift;
    my $event = $self->event;
   
    my $pool = $self->pool;
    my $struct = $self-> struct; assert ( $struct );

    my $actions = $pool;
    my $ind = 0;

    pd "? = alternatives: ";
    my $c=0;
    foreach ( @$actions ) {
	if ($c) { pd " * "; }
#	pd $actions->[$c++]->condition;
    }
    pd "\n";

    my @way = $self -> check_actions ( $actions );

    if ( $#way == 0 ) {
	my $way = $way[0];
	
	assert( ref $self->pool_cd ) if DEBUG;
	( $self->pool_cd -> [$way] )++ ;   ### registry
	my $el = $actions->[$way];
	if ( defined($el->max) and 
	     ( $self->pool_cd->[$way] > $el->max ) ) {
	    $self->error ( 'The element', 
			   ' is repeated over its maximum allowed occurs' );
	    return [ 1 ];  ### to not generate two errors
	}
	return $actions->[$way];

    } elsif ( $#way < 0 )  {

	if ( $self->check_finish ) {
	    my @res = $self-> pool_complete (); ## is this pool incomplete
	    if (not scalar @res) {  ## if complete
		return $self->finish_elem;
	    } else {
		$self-> error ( 
				'One or more of the required elements ',
				'are not present' );
#		foreach (@res) {
#		    pd " ? - $_->condition\n";
#		}                                  ####### ??!

		return $self->finish_elem;
	    }
	}
	return [];

    } elsif ( $#way > 0 )  {
	$self->error ( "FATAL/INTERNAL: SD Machine AMBIGUITY: ", 
		       join ( ' ', @way ), "\n" );
	foreach ( @way ) {
	    print ": $_\t", $actions->[$_]->condition, "\n";
	}
	die;
    }

}

###############################################################################
# S U B   POOL_COMPLETE
###############################################################################

sub pool_complete {
    my $self = shift;
    my $pool = $self->pool;

    my $c = 0; my @res = ();
    foreach ( @$pool ) {
	my $e = $_;
	if ( defined( $e->min ) and (
				     ( $e->min()
     				      and 
				     not defined ( $self->pool_cd->[$c] ) )
				     or
				     ( defined ( $self->pool_cd->[$c] )
						 and
				       ($self->pool_cd->[$c] < $e->min () ) ) 
				     )
	     ) {
	    push @res, $_;
	}
	$c++;
    }
    return @res;
}


###############################################################################
# S U B   E M P T Y _ P R O C 
###############################################################################

sub empty_proc {
    my $self = shift;
    my $event = $self->event;
   
    my $struct = $self-> struct; assert ( $struct );

    pd "? : Expecting final event" , " (" , $self->finisher . ") " ;
    pd ": ";

    if ( $self->check_finish   ) {
	pd "OK\n";

	return $self->finish_elem;
    } else {
	pd "bad\n";
	warn "Wrong situation: non-empty element of an empty type.";
				# handle this !!!
	return [];
    }

####

}

1;











