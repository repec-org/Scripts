###############################################################################
#  The SD::SType class and related stuff.  
###############################################################################

use Class::Generate qw( &class );


use strict;
use Devel::Assert ':DEBUG';
use SD::STypeExt;
use SD::STypeMake '&make';


#####  SD::SType 

class( 'SD::SType' =>
       {
	# input params
	name => "\$",         ### SType name 
	
	parent => "\$",       ### upper type's reference

	doctype_class =>"\$", ### class name of the target data object
	ctype => "\$",        ### logical content-type 

	ignore_ws_cdata => "\$",   ### white-space cdata 
	ignore_comments => "\$",   ### comments 
	
###	root => "\$",         ### if the type is root,
	
	# sequence
	# choice
	# string (CDATA)
	# MIXED
	# EMPTY
	# ANY
	
	elements => "\$",   ### array reference 
	
	# vars

###	stype => "\$",        ### SD::Structure type
	stype_data => "\$",   ### data for the SD::Structure
	                      ### graph - [['seq', ], occur]
	                      ### pool  
	                      ### empty
	                      ### any

	structures => "\%",   ### The hash of ready-made structure 
	                      ### objects for different container element names
### 	structure => "\$", 

	typestable => "\%",   ### Typenames symbol table

	element_names => "\%", ### hash for checking doubled element names...

	}, 
       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);

##############################################################################

package SD::SType;


use strict;
use Devel::Assert ':DEBUG';

use SD::XMLStruct;

use Class::Generate qw( &class );

##### SD::DocType  

class ( 'SD::DocType' => [ 
			   stype     => "\$",
			   root      => "\$",
			   structure => '$',
	                   class => "\$",   ### class name of the target 
                                            ### data object
			   ],
-options  => { allow_redefine => 1},
	);



########  make_doc_type   #####################################################

sub SD::DocType::make_doc_type {
    my $class = shift;
    my $root  = shift;

    my $self = $class -> new ( root => $root );
    
    my $stype = SD::SType::sequence -> make_new ( 'DOCTYPE' );

    $self -> stype ( $stype );
    $stype -> parent ( undef );

    my $XMLD  = & SE_XMLDecl ();
    my $DTD   = & SE_DTD     ();
    my $PI    = & SE_PI      ();
    my $rootE = & SE_element_open ( $root );

    my $doc = ['seq', 
	       $XMLD,     "?", 
	       $PI,       "*", 
	       [
		'seq', 
		$DTD,  "1", 
		$PI,   "*" 
		], '?',
	       $rootE,    '1'
	       ];

    $stype -> set_sequence ( $doc );

    return $self;
}



sub SE_element_open {

    my $name = shift; assert ( $name ) if DEBUG;
    my $stype = shift || $name;
    my $method = shift || 'element';

    assert( $stype );

    return build_element ( 'open', $stype, undef, 1, ['element', $name], 
			   undef, undef, $method );
}


sub SE_XMLDecl {
    
    my $method = shift || 'special';
    my $el;
    $el = build_element ( undef, undef, undef, 1, 'XMLDecl', 
			  undef, undef, $method );
    return $el;
}


sub SE_DTD {
    
    my $method = shift || 'special';
    my $el;
    $el = build_element ( undef, undef, undef, 1, 'DTD', 
			  undef, undef, $method );
    return $el;
}


sub SE_PI {
    
    my $method = shift || 'special';
    my $el;
    $el = build_element ( undef, undef, undef, 1, 'PI', 
			  undef, undef, $method );
    return $el;
}


sub SE_cdata {
    my $condition = shift;   ### cdata ('context') condition 
    
    my $method = shift || 'cdata';
    my $el;

    $el = build_element ( undef, undef, undef, 1, ['cdata', $condition ], 
			  undef, undef, $method ) 
	if defined $condition;

    $el = build_element ( undef, undef, undef, 1, 'cdata', 
			  undef, undef, $method ) 
	if not defined $condition;
    
    return $el;
}


sub SE_cdata_RE {
    my $RE = shift;   ### cdata ('context') condition 
    assert( $RE );
    
    my $method = shift || 'cdata';
    my $el;

    $el = build_element ( undef, undef, undef, 1, ['cdata', [ 'RE', $RE ] ], 
			  undef, undef, $method ) ;
    return $el;
}




sub SD::DocType::produce_structure {
    my $self = shift;

    my $stype = $self -> stype;
    
    my $str =  $stype -> bind_root ( 'DOCTYPE', 'DOCTYPE' ) ;

    if ($str) {
	$str -> finish_elem () -> condition ( 'EOF' );
	$str -> finisher ( 'EOF' );
	
	$self-> structure ( $str );
    }

    return $str;
}


#######################################

sub make_sequence_type { 
    my  $self = shift;
    
    return $self -> SD::SType::sequence::make_new ( @_ );
}

#######################################

sub make_choice_type { 
    my  $self = shift;
    
    return $self -> SD::SType::choice::make_new ( @_ );
}

#######################################

sub make_default_structure {
    my $self = shift;

    my $el_name = shift;

    my $empty_cdata = ['cdata', ['RE', '\s+'] ];
    my $structure = SD::Structure -> new 
               ( 
#   name => $s_name,
		 doctype_class => 'SD::Doc',
		 strict_closing => 1,
			);

    $structure -> starter ( ['element', $el_name ] );

    $structure -> finish_elem (
			     SD::SElement->new(
					       type => 'close',
					       consume => 1,
					       condition => 
					       ["endtag",$el_name],
					       )
			       );
    $structure -> error_elem ( SD::SElement-> new ( 
						    type => 'open', 
						    struct => 
						    $SD::XMLStruct::ERROR,
						    consume => 0, 

						    ) );

    return $structure;
}


##################################################################
#####################  NAME  BINDING  ############################
##################################################################

sub bind_root {
    my $self = shift;
    my $root_element = shift;
    my $root_type    = shift;

    my $structure;
    my $result;

    my $type = $self-> find_stype_by_name ( $root_type );

    if (not $type) {
	die;
    }

    $structure = $type -> produce_element_of_type ( $root_element,
						    $root_type );
    if (not $structure) {
	return undef;
    }
    $result = $type -> bind_names ( $structure );

    if (not $result) {
	return undef;
    }
    return $structure;
}


sub bind_names {
    my $self = shift;
    my $structure = shift;

    return 1 if $structure->resolved() ;

    if ( $structure -> graph ) {

	my $gr = $structure->graph ();
	my $node_no = 1; 
	my $element;

	while ( $node_no < $gr -> final ) {
	    ( $element ) = $gr-> get_item ( $node_no );
	    $self->bind_selement ( $element )
		or return 0;

	    $node_no ++;
	}
	$structure->resolved ( 1 );

    } elsif ( $structure -> pool ) {

	my $pool = $structure->pool ();
	my $node_no = 0; 
	my $element ;

	foreach ( @$pool ) {
	    $element = $_ ;
	    $self->bind_selement ( $element )
		or return 0;
	    $node_no ++;
	}
	$structure->resolved ( 1 );

    } else {
	die;
	$structure->resolved ( 1 );
    }
    return 1 ;
}


sub bind_selement {
    my $self = shift;

    my $element = shift;  assert( $element );

    my $name;
    if ( $element -> isa ( 'SD::SElement' ) ) {
	$name = $element -> struct_name  ;
    } 
    if ( $name ) {

	my ( $el, $t ) = split '<' , $name;
	$t = $el if not $t;
	assert( $t );

	my $type = $self-> find_stype_by_name ( $t );
	if ($type) {
	    my $str = $type -> produce_element_of_type ( $el, $t );
	    $element -> struct ( $str );
	    return $type -> bind_names ( $str );
	} else {
	    warn "Can't find type '$t'";
	    return undef;
	}
    }
    return 1;
}


sub find_stype_by_name {

    my $self = shift;
    my $typename  = shift; assert( $typename ) if DEBUG;

###     print " ! FINDTYPE REQUEST\n",
###     "SELF: '", $self->name, "'\n",
###     "TYPENAME: '$typename'\n";

    return $self if ($typename eq $self->name);
    
    my $stype = $self->typestable ( $typename );   
    my $lookup = $self;
    
    while ( not defined $stype ) {

	if (not defined $lookup ) { 
	    ### the type is unknown (not defined)
	    return undef; 
	}
	$lookup = $lookup-> parent () or next;
	$stype = $lookup -> typestable ( $typename ) ;
    }

    if( not defined $stype) { return undef; }

    assert( $stype -> name () eq $typename );

    return ( $stype );
}


#####################################################################
#####  STYPE  CREATION  ROUTINES   ##################################
#####################################################################

sub new_type {
    my $self = shift; assert( $self ) if DEBUG;
    
    my $name = shift; assert( $name );
    my $ctype = shift;  ###   assert( $ctype );
    my $parent ;

    my $class;
    if ( not ref $self ) {
	$parent = undef;
	$class = $self;
    } else {
	$parent = $self;
	$class = ref $self;
	$class = 'SD::SType::'.$ctype;
    }

    my $type = $class -> new(
				name => $name,
				ctype => $ctype,
				parent => $parent,
				);
    if ( $parent ) {
	assert ( not defined $self->typestable( $name ) ) if DEBUG;
	$self->typestable ( $name, $type );
    }

    return $type;
}


#############################################################
################  PRODUCTIONS STAGE  ########################
#

############  PRODUCE ELEMENT OF TYPE  #################################

sub produce_element_of_type { 
    my $self = shift;
    my $element = shift;
    my $stype_name = shift;
    my $structure;

    ### first task is to look-up the name in the 
    ### set of types' symbol tables
    
    my $stype = $self->find_stype_by_name( $stype_name );   

    if( not defined $stype) { return undef; }

    assert( $stype -> name () eq $stype_name );

    $structure = $stype->produce_structure_object ( $element );

    return $structure;
}

use SD::XMLStruct;

my $empty_cdata = ['cdata', ['RE', '^\s+$'] ];
my $comments = 'comment';


#########  PRODUCE STRUCTURE OBJECT  ##########################################

sub produce_structure_object { 
    my $self = shift;
    my $element = shift;

    my $str;

    if (not defined $element) {
	$element = $self->name;
    }

    if ( defined $self-> structures ($element) ) {
	### Has such structure been already created ?
	return $self->structures ($element) ;
    }
	
    ### otherwise create a structure object
    
#    if ($self->ctype eq 'sequence' ) {
#    } else {
#	die 'not implemented ctype';
#    }
    $str = $self->produce_structure_object_core ( $element ) ;
    $str -> name ( $element );

    ### Save the structure object in a hash, for that element name
    $self-> structures ( $element, $str );   

    if ( defined $self -> doctype_class ) {
	$str -> doctype_class ( $self -> doctype_class );
    }

    if ( $self-> ignore_ws_cdata ) {
	$str -> ignore_pre ( [$empty_cdata]  );
    } 
    if ( $self-> ignore_comments ) {
	$str -> ignore_post( [$comments] );
    }
    
    resolve_names_to_elements ( $str );

    return $str;
}


sub produce_structure_object_core  {         #####  default, virtual method
    my $self = shift;
    die "METHOD SHALL BE IMPLEMENTED IN A DERRIVED CLASS '". 
	ref( $self ) . "'" ;
}


#### transfer here the SD::XMLStruct::build_element_structure
#### and the SD::XMLStruct::bind_names_to_elements ( $str );

sub build_element {
    my $type = shift; 
    my $struct_name = shift;
    my $struct = shift;
    my $consume = shift || 0;
    my $condition = shift;
    my $min = shift;
    my $max = shift;
    my $method = shift;

    return SD::SElement->new(
			     type => $type,
			     consume => $consume,
			     condition => $condition,
			     struct_name => $struct_name, 
			     struct => $struct,
			     min => $min, 
			     max => $max,
			     method => $method,
			     );
};

sub build_open_element { 
    my $name = shift;
    my $stype = shift;
    if ($name =~ /</) {
	(my $n, $stype) = split ( '<', $name );
	return build_element ( 'open', $name, undef, 1, ['element', $n], 
			       undef, undef, 'element' );
    } else {
#	my ( $type ) = split '>', $name;
#	return build_element ( undef, undef, undef, 1, [$type] );
	die "Bad name $name";
    }
}

#####  from XMLStruct.pm: start ##################### 

sub resolve_names_to_elements {
    my $structure = shift;  assert( $structure );

    my $graph = $structure -> graph();
    my $pool = $structure ->  pool ();
    my $pool_data = $structure -> pool_data ();

    my $node_no ; 
    my $element ;

    if ( $graph ) { 
    
	$node_no = 1 ;
	while ( $node_no < $graph -> final ) {
	    
	    ( $element ) = $graph -> get_item ( $node_no );	    

	    assert( $element ) if DEBUG;
	    
	    my $name;
	    if ( not $element -> isa ( 'SD::SElement' ) ) {
		$name = $element;
		my $item = $graph -> get_item_ref ( $node_no ) ;
#		print "NAME ELEMENT: '$name' \n";
		$element = build_open_element( $name );
		@$item = ( $element );
	    }
	    $node_no ++;
	}

	if ( $node_no eq $graph->final )  {
	    ( $element ) = $graph -> get_item ( $node_no );	    
	    if ($element == -1) {
		my $item = $graph -> get_item_ref ( $node_no ) ;
		@$item = ( $structure->finish_elem );
	    }
	}

    } elsif ($pool) {

	$node_no = 0 ;

	while ( $node_no <= $#$pool ) {
	    
	    ( $element ) = $pool->[$node_no];
	    my $name;
	    if ( not ref ($element) ) {
		die;
		$name = $element;
		my $el = build_open_element( $name );
		$pool-> [ $node_no ] = $el;
		my $el_occur = $pool_data->[$node_no];
		if ( defined $el_occur ) {
		    assert ( ref $el_occur eq 'ARRAY' );
		    my ( $min, $max ) = @$el_occur;
		    $el->min ($min) if defined $min ;
		    $el->max ($max) if defined $min ;
		}
	    }
	    $node_no ++;
	}
# 	push @$pool, $structure->finish_elem;  ### HA !!!
    }
}
                                                             


#####  from XMLStruct.pm: end ####################### 

__END__


sub make_sequence_type {
    my $self = shift; assert( $self );
    my $name = shift; assert( $name );
    my $symtable = shift; 
    
    
}

sub make_sequence_type {
    my $self = shift; assert( $self );
    
    
}


sub make_sequence_type {
    my $self = shift; assert( $self );
    
    
}


sub make_sequence_type {
    my $self = shift; assert( $self );
    
    
}





1;

__END__

=pod

=head1 DESCRIPTION

XML view:

    - expect any PI ?
       - any specific PI target?
          - targets?
       - require it?

    - ignore DTD ?
    - ignore comments ?

