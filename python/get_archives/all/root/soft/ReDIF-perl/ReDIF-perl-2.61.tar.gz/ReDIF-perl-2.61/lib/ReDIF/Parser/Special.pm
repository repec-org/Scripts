package ReDIF::Parser::Special; 

#  $Id$
#$VERSION = do { my @r=(q$Revision$=~/\d+/g); sprintf "%d."."%02d"x$#r,@r }; 


use strict; 
use vars qw( @ERRORS @WARNINGS );
use vars qw( $value $result $evaluation );

sub error {
    my $text = shift;
    push @ERRORS, $text;
}

sub warning {
    my $text = shift;
    push @WARNINGS, $text;
}

1;
