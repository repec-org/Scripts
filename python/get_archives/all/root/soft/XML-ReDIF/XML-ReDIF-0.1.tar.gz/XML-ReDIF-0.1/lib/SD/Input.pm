#!/usr/bin/perl

package SD::Input;

use Class::Generate '&class' ;


class ( 'SD::Input' => [

			filename => {
			    type => "\$", 
			    required => "1",
			},
			parser => {
			    type => "\$", },
			SDMachine => {
			    type => "\$",
			},

], 

       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);

use XML::Parser;
use vars qw( $MACHINE );


#############################################################################

sub XMLDecl {
    my $Expat = shift;
    my $version = shift;
    my $encoding = shift;
    my $standalone = shift;
    
    my $IE = new_event ( 'XMLDecl', $version, 
			 {enc => $encoding,
			  stndal => $standalone, }
			  , $Expat );

    $MACHINE -> input ( $IE );
    1;
}
#############################################################################

#############################################################################
sub Doctype {
    my $Expat = shift;
    my $name = shift;
    my $sysid = shift;
    my $pubid = shift;
    my $internal = shift;
    
    my $IE = new_event ( 'DTD', $name, 
			 { sysid => $sysid,
			   pubid => $pubid,
			   internal => $internal
			   }
			 , $Expat );
    
    $MACHINE -> input ( $IE );
}
#############################################################################


sub start {
#    my $self =shift;

    my $file = shift;
    $MACHINE = shift;

#    print "Reading a file: $file\n";

    my $parser = XML::Parser -> new ( Style => 'Stream' );

#    my $parser = XML::Parser -> new ( );
#    $parser -> setHandlers ( Start => \&StartTag,
#			     End   => \&EndTag,
#			     Char  => \&Char , 
#			     Proc  => \&PI , 
#			     Final => \&EndDocument , 
#    );

    $parser -> setHandlers ( 'XMLDecl' => \&XMLDecl );
    $parser -> setHandlers ( 'Doctype' => \&Doctype );
    $parser -> parsefile ( $file );
	
}


###########################################################################

class ( 'SD::InpEvent' => [

			   type => {
			       type => "\$", 
			       required => "1",
			   },
			   data => {
			       type => "\$", },
			   
			   data2 => {
			       type => "\$",
			   },
			   reference => {
			       type => "\$",
			   },
			   parser => {
			       type => "\$",
			   },
			   '&describe' => q!
			   my $res = "Type: $type";
			   if ($data) { 
			       my $d = $data;
			       $d =~ s/\n|\r/\^M/;
			       $res .= "\tData: '$d'"; }
			   return $res;
			   !
], 

       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);


sub input_event_condition_checker { 
    my     ( $cond, $inp, $context ) = @_;

    $DB::single = 1;

###    assert ( $context or $inp -> UNIVERSAL::isa( 'SD::InpEvent' ) );

    if      ( ref ( $cond ) eq 'ARRAY' ) {
    	return &condition_array ;
    } elsif ( ref ( $cond ) eq 'HASH' ) {
	return &condition_hash ( @_ );
    } elsif ( ref ( $cond ) eq 'CODE' ) {
	return &condition_code ( @_ );
    } elsif ( not ref ( $cond )       ) {
	return &condition_scalar ( @_ );
    } else {
	warn "Bad condition ignored: " , $cond;
	return undef;
    }
};

use Devel::Assert ':DEBUG';
use strict;

my %condition_contexts = (
    type => 1, 
    data => 1, 
    data2 => 1,
);

sub condition_scalar {

    my ( $cond, $inp, $context ) = @_;
    assert ( defined $inp ) if DEBUG;

    if ( not $context ) {
	if ( $cond =~ /</ ) {
	    my ( $type, $data ) = ( $inp-> type, $inp->data) ;
	    my ( $ct , $cd ) = split '<', $cond;
	    return 0 if ( $ct ne $type );
	    return 0 if ( $cd ne $data );
	    return 1;
	} else {
	    return 1 if $cond eq $inp->type;
	    return 0;
	}
#	return ( $inp eq $cond ) ;   

    } elsif ($cond eq '') {

	return 1 if $inp ne '';

    } else { 

	assert( $condition_contexts{$context} ) if DEBUG;
	return ( $inp eq $cond ) ;
    }
}
  

sub condition_array {

    my ( $cond, $inp, $context ) = @_;
###    assert ( $inp ) if DEBUG;

    if ($context) {
	return &condition_operator ( $inp, $cond->[0], $cond->[1] );
    } else {
        my $type = $cond->[0];
        my $data = $cond->[1];
	my $data2 = $cond->[2];
	return 0 if not 
	    input_event_condition_checker ( $type, $inp->type, 'type' );
	return 1 if not defined $data;
	return 0 if not 
	    input_event_condition_checker ( $data, $inp->data, 'data' );
	return 1 if not defined $data2;
	return 0 if not 
	    input_event_condition_checker ($data2, $inp->data2, 'data2');
	return 1;
    }
}

### OPERATOR COMPARING SUPPORTED:
### eq, ne, RE, NR, ==, !=, >, < 

sub condition_operator {
    my ( $inp, $op, $val ) = @_;
    assert( $inp );
    assert( $op );
    assert( $val );

###    print "oper: $inp $op $val\n";

    if (      $op eq 'eq' ) { 
	return ( $inp eq $val );

    } elsif ( $op eq 'ne' ) { 
	return ( $inp ne $val );

    } elsif ( $op eq 'RE' ) { 
	return ( $inp =~ /$val/ );

    } elsif ( $op eq 'NR' ) { 
	return ( $inp !~ /$val/ );

    } elsif ( $op eq '==' ) { 
	return ( $inp == $val );

    } elsif ( $op eq '!=' ) { 
	return ( $inp != $val );

    } elsif ( $op eq '>' ) { 
	return ( $inp > $val );

    } elsif ( $op eq '<' ) { 
	return ( $inp < $val );
    }
}

sub condition_hash {
    my ( $cond, $inp, $context ) = @_;
    assert ( $inp ) if DEBUG;
    
    if ( $context ) {
	return 0 if not ref ($inp ) eq 'HASH' ;
	my $hash = $inp;
	foreach my $k ( keys %$cond ) {
	    return 0 if not exists $inp->{$k};
	    next if ($cond->{$k} eq '') and defined $inp->{$k};
	    return 0 if not
		input_event_condition_checker( $cond->{$k}, 
					       $hash->{$k},
					       $context );
	}
	return 1;
    } else {
	if ( $cond -> {logic} ) {

	    ########  make check_value !!! or reform i_e_c_c ()
	    ########  make ->{logic} here!

	} else {
	    foreach my $k ( keys %$cond ) {
		return 0 if not defined $inp->$k();
		return 0 
		    if not 
			input_event_condition_checker( $cond->{$k}, 
						       $inp->$k (), 
						       $k );
	    }
	    return 1;
	}
    }
}


sub condition_code {
   my ( $cond, $inp, $context ) = @_;
   assert ( $cond ) if DEBUG;
   
   return &$cond ( $inp );
}

### sub condition_array {
###    my ( $cond, $inp, $context ) = @_;
###    assert ( $inp ) if DEBUG;
### }










###############################################################################
# testing class SD::Echo
class ( 'SD::Echo' => [
		       name => {
			       type => "\$", 
			   },
		       condition => "\$",
		       cstat => "\$",
		       new => {post => '$cstat = {};'},
		       ], 

#       -use => [ "Devel::Assert ':DEBUG'" ],
       -options => {  allow_redefine => 1 },
);


sub SD::Echo::input {
    my $self = shift;
    my $event = shift;

    return if ( $event->type eq 'cdata' and $event->data =~ /^\s+$/ ) ;
    
    print "\n * INPUT: ", $event->type;    print "\n";
    if ( defined $event->data ) {
	print " : data : ", "'", 
	$event->data,
	"'";
    }

    if (defined $event->data2 and not ref $event->data2) {
	print "\td2: '", $event->data2, "'";
    } 

    print "\n";
    if (ref $event->data2 eq 'HASH') {
	my $hash = $event->data2;
	foreach ( keys %$hash ) {
	    print "\t", $_, " =>\t", $hash->{$_}, "\n";
	}
    }
    
    print " . line: " , $event->reference->[0],"\n";

#    my $ch = 
#	input_event_condition_checker( $self->condition, $event ) 
#	    ? 'true' : 'false' ;
#
#    $self->cstat->{$ch}++;
#    print " ? Condition: (" , $ch, ")\n" ;

}




###############################################################################

sub new_event { 
    my $type = shift;
    my $data = shift;
    my $data2 = shift;
    my $parser = shift; assert ( $parser ) ;

    return SD::InpEvent->new ( type => $type, 
			       data => $data, 
			       data2 => $data2,
			       parser => $parser,
			       reference => [ 
					      $parser -> current_line, 
					      $parser -> current_column, 
					      $parser -> current_byte
					      ]
			       );
    
}

###############################################################################


sub StartTag {
    my $Expat = shift;
    my $element = shift;

    my %attr = %_;

    my $IE = new_event ( 'element', $element, \%attr, $Expat );

    $MACHINE -> input ( $IE );
}


###############################################################################

sub EndTag {
    my $Expat = shift;
    my $element = shift;

    my $IE = new_event ( 'endtag', $element, undef, $Expat );

    $MACHINE -> input ( $IE );
}

###############################################################################

sub Text {
    my $Expat = shift;
    my $cdata = $_;

    my $IE = new_event ( 'cdata', $cdata, undef, $Expat );

    $MACHINE -> input ( $IE );
}

sub Char {
    my $Expat = shift;
    my $cdata = shift;

    my $IE = new_event ( 'cdata', $cdata, undef, $Expat );

    $MACHINE -> input ( $IE );
}

##############################################################################

sub PI {
    my $Expat = shift;
    my $target = shift;
    my $data   = shift;

    my $IE = new_event ( 'PI', $target, $data, $Expat );

    $MACHINE -> input ( $IE );
}

###############################################################################

sub EndDocument {
    my $Expat = shift;

    my $IE = new_event ( 'EOF', undef, undef, $Expat );

    $MACHINE -> input ( $IE );
}

###############################################################################



__END__
###############################################################################

sub EndTag {
    my $Expat = shift;
    my $element = shift;

}

###############################################################################

sub EndTag {
    my $Expat = shift;
    my $element = shift;

}

###############################################################################

sub EndTag {
    my $Expat = shift;
    my $element = shift;

}

###############################################################################

sub EndTag {
    my $Expat = shift;
    my $element = shift;

}




sub EndTag {

}



