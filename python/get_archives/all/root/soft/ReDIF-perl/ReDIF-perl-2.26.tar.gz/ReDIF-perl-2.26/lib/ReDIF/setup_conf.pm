    
# Please do not modify this unless you know what you are doing.
# created by Configure of the ReDIF perl package.
    
package ReDIF;
    
    
    1;
