package SD::SType;

use SD::SType;
use Devel::Assert ':DEBUG';

# use Exporter;
# @EXPORT_OK = qw( &make );

###############################################################################


=pod 
=head1 NAME 

SD::STypeMake module - the SD::SType supplement

=head1 DESCRIPTION

To my understanding, a type of data when defined by a programmer is
viewed from the point of view of a higher-level type.  Or is that
always right?

=cut



sub make {
    my $self = shift;
    my %par = @_;
    
    my $name        = $par{name};   assert( $name ) if DEBUG;
    my $description = $par{description};
    my $extends     = $par{extends};
    my $options     = $par{options};
    my $content     = $par{content};   assert( $content ) if DEBUG;
    my $class       = $par{class};
    
    my $Type ;

    if ( $content eq 'element' ) {
	$Type = $self->make_element_content_type ( @_ );
    } elsif ( $content eq 'cdata' ) {
	$Type = $self->make_cdata_content_type ( @_ );
    } else {
	die "NOT IMPLEMENTED CONTENT TYPE: $content";
    }

    assert $Type;

    if ($class) {
	$Type->doctype_class( $class ) ;
    } 
    return $Type;
}



sub inherit_from {

    my $self = shift;
    my $super_class = shift;

    my $supertype = $self -> find_stype_by_name ( $super_class );
    if ( not $supertype ) {
	die "Base type '$supertype' is unknown";
    }

    assert ( ref ($self) eq ref( $supertype ) );

    ###  Copy some general parameters

    foreach ( qw( ctype ignore_ws_cdata ignore_comments 
		  typestable doctype_class 
		  ) ) {
	$self-> $_ ( $supertype -> $_ () );
###	print " _ inherited parameter: $_\n";
    }

    if ( scalar ( $supertype -> element_names_keys  ) ) {
	my %h = $supertype -> element_names ;
	$self-> element_names ( \%h );
    }

    ###  Copy main containtment data

    if ( ref $supertype->elements ) {
	my @temp = @{$supertype->elements};
	$self -> elements ( \@temp );

###	print " _ inherited array (elements): @temp\n";

    } else { die; }

    if ( ref $supertype->stype_data ) {
	my @temp = @{$supertype->stype_data};
	$self -> stype_data ( \@temp );

###	print " _ inherited array (stype_data): @temp\n";
    
    } else { die; }

#    if ( ref $supertype->element_names ) {
#	my %temp = @{$supertype->element_names};
#	$self -> stype_data ( \@temp );
####	print " _ inherited array (stype_data): @temp\n";
#    } else { die; }

    return ( 1 );
}


use SD::CM;

sub make_element_content_type {
    my $self = shift;
    my %par = @_;
    
    my $name        = $par{name};  
    my $description = $par{description};
    my $extends     = $par{extends};
    my $options     = $par{options};
    my $content     = $par{content}; 
#    my $type        = $par{type};

    my $element     = $par{element}; assert( $element ) if DEBUG;
    my $Type ; 
    
    if ( $par{type} eq 'seq' ) {
	$Type = $self -> make_sequence_type ( $name, $extends );
	my $seq_in = $element; 
	my @seq = ('seq');
	if ( ref $seq_in eq ARRAY ) {
	    foreach ( @$seq_in ) {
		push @seq, make_sequence_element ( $_ );
	    }
	    $Type -> set_sequence ( \@seq );
	} else {
	    assert( not ref $seq ) if DEBUG;
	    my ($graph_model, $occur) = SD::CM::build_graph_model( $seq );
	    assert( defined $graph_model );
	    $Type -> set_sequence ( $graph_model );
	    assert( not $occur ) if DEBUG;
	}
    } elsif ( $par{type} eq 'choice' ) {

	$Type = $self -> make_choice_type ( $name, $extends );
	my $cho = $element;
	my @pool = ();

	if ( ref $cho eq ARRAY ) {
	    foreach ( @$cho ) {
		my $el = $_->{name};
		
		if ( $Type -> element_names($el) ) {
		    warn "Doubled element of name '$el' in a pool " , 
		    "structure <" , $Type->name, ">: ignored\n";
		    next;
		}
		$Type -> add_element ( make_ch_element ( $_ ) );
		$Type -> element_names($el, 1) ;
	    }
	} else {
	    die 'NOT IMPLEMENTED STRING-DEFINITION OF A CHOICE' ;
	}
    }
    
    &apply_options ( $Type, $options );
    return $Type;
}



sub make_sequence_element { 
    my $defin = shift;
    my $occur = $defin->{occurs} || '1';
    my $single = shift || 0;

    if ($defin->{choice}) {

	my $alt = [ 'alt' ];
	foreach ( keys %$defin ) {
	    my $no = $_;
	    next if $no !~ /^\d+/;
	    my $v = $defin->{$no} ;
	    push @$alt, make_sequence_element ( $v, 1 );
	}
	return $alt if $single; 
	return ( $alt, $occur );

    } elsif ( $defin->{sequence} ) {
	
	my $seq = ['seq'];
	foreach ( @{$defin->{sequence}} ) {
	    push @$seq, make_sequence_element ( $_ );
	}
	return $seq if $single; 
	return ( $seq, $occur ) ;

    } else {

	my $el = make_sequence_element_single ( $defin ) ;
	return $el if $single; 
	return ( $el, $occur );
    }
}

# el:
#     name => 
#     type => 
#     attributes => {}
#     occur => 
#     method => 

sub make_sequence_element_single {
    my $e = shift;

    my $name = $e->{name};
    my $type = $e->{type} || $name;
    my $method = $e->{method} || 'element';
    my $attributes = $e->{attributes};

    my $condition = [ 'element', $name ];

    if ($attributes) {
	$condition->[2] = $attributes;
    }

    my $se = SD::SElement-> new (
				 type => 'open',
				 struct_name => "$name<$type",
				 condition => $condition,
				 method => $method,
				 consume => 1,
		      );

    return $se;
}

sub make_ch_element {
    my $d = shift;

    my $el = make_sequence_element_single ( $d );

    if ( (not defined $d->{min}) and (not defined $d->{max}) ) {
	if ($d->{occurs}) {

	    my %occurs = ( '*' => [undef,undef],    ####  [min, max]
			   '?' => [undef, 1],
			   '+' => [1, undef],
			   '1' => [1, 1] );
	    my $o = $occurs{$d->{occurs}};
	    $el->min( $o->[0] );
	    $el->max( $o->[1] );
	}
    } else {
	if (defined $d->{min}) {
	    $el->min ( $d->{min} );
	}
	if (defined $d->{max}) {
	    $el->max ( $d->{max} );
	}
    }
    return $el;
}



##############################################################################
############################   C D A T A   ###################################
##############################################################################

sub make_cdata_content_type {
    my $self = shift;
    my %par = @_;
    
    my $name        = $par{name};     assert( $name ) if DEBUG;

    my $description = $par{description};
    my $extends     = $par{extends};
    my $options     = $par{options};
    my $content     = $par{content};
    my $class       = $par{class};
    my $_type       = $par{type} || 'choice';

    my $cdata       = $par{cdata}; assert( $cdata ) if DEBUG;
    my $Type ; 

#    valtype => single | list | free
#    value   => 'regular expression', 
#    enumeration => [],
#    leave_ws  => 0 | 1,     ###  boundary whitespace treatment
#    non-empty => 0 | 1
#    list_separators => '\s*(,|;|-)\s*|\s+', 
#    default =>  "value"

##    print "??? ", $name , " / ", $cdata-> {'non-empty'}, "\n";
    #### ?


    if ( $_type eq 'choice' ) {
	$Type = $self -> make_choice_type ( $name, $extends );

	my $SE = SD::SElement->new( 
				    condition => 'cdata',
				    method => 'cdata', 
				    min => ( $cdata->{'non-empty'} ? 1 : 0 ),
				    max => 1,
				    consume => 1,
       				    );
#	print "?>> $name: min : ", $SE->min , "\n";
	$Type -> add_element ( $SE );

	my $package = 'CD::Doc::STM::P' . $SD::SType::syntetic_package_no ++; 

	$Type-> doctype_class( $package );

	my $def_header = 
	    "{ package ${package};\n" .
	    "\@ISA = ( 'SD::Doc' );\n\n".
	    " sub cdata {\n".
	    "    my \$self = shift;\n".
	    "    my \$mach = shift;\n".
	    "    my \$value = \$mach->event()->data();\n";
 
	my $def_save = 
	    "    push \@{\$self->contents}, \$value;\n";
#	    "    \$self->contents( \$value );\n";

	my $def_footer = " }\n\n}\n";

	my $vcheck = ''; my $acheck = '';

	my $definition;

	if ( $cdata->{value} ) {   

	    $vcheck = "\(\$value =~ /^" . $cdata->{value} . "\$/ ) ";

	} elsif ( $cdata->{enumeration} ) {

	    my $enum = $cdata->{enumeration} ;
	    $acheck = "    my \%vals = (\n";
	    foreach ( @$enum ) {
		$acheck .= " '$_' => 1,\n";
	    }
	    $acheck .= " );\n";
	    $vcheck = " ( \$vals{\$value} ) ";

	} 
	my $v_prepare = '    $value =~ s/^\s+|\s+$//g;' . "\n" 
	    if not $cdata->{leave_ws}; 

	$v_prepare .= '    return if $value eq \'\';  ' 
	    unless $cdata->{'non-empty'};
 

	if ( defined $cdata->{valtype} and $cdata->{valtype} eq 'list' )  {
#	    assert( $cdata->{list_separator} );
	    die "NOT IMPLEMENTED";

	} else {
	    
	    $vcheck = "    return if $vcheck ; \n" if ( $vcheck );
		
	    if ($acheck) {
		$vcheck = $acheck . $vcheck;
	    }
	}

	if (defined $cdata -> {valtype} and $cdata -> {valtype} eq 'free') {
	    if( (defined $cdata->{'non-empty'}) 
		and
		($cdata->{'non-empty'}) ) {

		### no need to check 

		$vcheck = "    return 1 if \$value ne '';\n";

	    } else {

		$def_header = '';
		
		if ( not $cdata->{leave_ws} ) {
		    $SE -> method ( 'cdata_strip' );
		}; 
		$Type -> doctype_class ( 'SD::Doc' );

	    }
	}
	
	my $error = "    \$mach->error( \"Value of type '".
	    $name . "' is incorrect\" ); \n"   ;

	if ($def_header) {
	    $definition = join( "\n", $def_header, $v_prepare ,
		$def_save,		
		$vcheck , $error , $def_footer );

#########
#           print "=" x 15, ' ', $Type->name, '/',   
#      	    $Type->doctype_class,  ' ',    "="x15  ,  "\n";
#            print $definition;  print "=" x 30, "\n";
#########
	    eval $definition;
	    if ( $@ ) { print "DEF ERROR: ", $@, "\n"; }
	}


    } else {
	die; 
    }

    &apply_options ( $Type, $options );
    $Type -> ignore_ws_cdata( 0 );

    return $Type;

}


sub apply_options {
    my $self = shift;
    my $options = shift;

    if ( defined $options->{ignore_ws} )  {
	$self->ignore_ws_cdata ( $options->{ignore_ws} );
    }

    if ( defined $options->{ignore_comments} )  {
	$self->ignore_comments ( $options->{ignore_comments} );
    }

#    if ( defined $options->{class} )  {
#	$self->doctype_class ( $options->{class} );
#    }
    
}


1;

__END__


my $type = {
    name    => 'NAME' ,
    description => 'name type description',
#	     extends => 'PARENT', 
#	     ctype   => 'string',
    ctype   => 'sequence',
    
    element_content => 1,  ### boolean
    
    content  => [
		 { 
		     ELEMENT => 'name',
		     attribute => {},
		     type => 'type',
		     occurs => '?',    # [0, 5] 
		 },
		 { 
		     CHOICE => 1,
		     occurs => '+',
		 }
		 ],
    
    
};


my $type = {
    name    => 'NAME' ,
    description => 'name type description',

#	     extends => 'PARENT', 
#	     ctype   => 'string',

    ctype   => 'string',
    options => { ignore_ws => 1 },
    type => 'RE',
    RE => 'expression',
    code => {
	pre => '',
	post => '', 
    }
    
    cdata_content => 1,  ### boolean
    
    content  => [
		 { 
		     ELEMENT => 'name',
		     attribute => {},
		     type => 'type',
		     occurs => '?',    # [0, 5] 
		 },
		 { 
		     CHOICE => 1,
		     occurs => '+',
		 }
		 ],
    
    
};



make parameters :

    name 
    description
    options 
    class
    extends
    content : element | cdata | mixed | special

    type => seq | choice
    element => [ els ]

el:
    name => 
    type => 
    attributes => {}
    occur => 
    method => 


cdata:
    valtype => multi | single
    non-empty => 1 | 0
    default =>  "value"




a simplest type definition: 
{ name => '1',
  content => 'element',
  type => seq,
  element => [ { name => 'X', type => 'Y', occurs => 1 } ], 
#  element => "(X<Y)",
}


